-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Schema Migration 03: Storage Buckets & Policies
-- ============================================================================
-- Configures public preview bucket and private source-files bucket with RLS
-- ============================================================================

-- 1. INSERT BUCKETS
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  (
    'buyweb-previews',
    'buyweb-previews',
    true,
    5242880, -- 5 MB limit for preview images
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']::text[]
  ),
  (
    'buyweb-source-files',
    'buyweb-source-files',
    false, -- Strictly PRIVATE bucket
    52428800, -- 50 MB limit for template zip packages
    ARRAY['application/zip', 'application/x-zip-compressed', 'application/octet-stream']::text[]
  )
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- 2. STORAGE POLICIES FOR buyweb-previews (Public read, admin write)
DO $$
BEGIN
  -- Select policy for public previews
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'previews_public_read'
  ) THEN
    CREATE POLICY "previews_public_read"
      ON storage.objects FOR SELECT
      TO public
      USING (bucket_id = 'buyweb-previews');
  END IF;

  -- Admin upload for previews
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'previews_admin_insert'
  ) THEN
    CREATE POLICY "previews_admin_insert"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id = 'buyweb-previews' AND public.is_admin(auth.uid())
      );
  END IF;

  -- Admin update/delete for previews
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'previews_admin_manage'
  ) THEN
    CREATE POLICY "previews_admin_manage"
      ON storage.objects FOR ALL
      TO authenticated
      USING (
        bucket_id = 'buyweb-previews' AND public.is_admin(auth.uid())
      );
  END IF;

  -- 3. STORAGE POLICIES FOR buyweb-source-files (Private, strictly admin upload, NO public select)
  -- Note: Customer downloads are handled exclusively through server-side signed URLs created with service_role.
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'source_files_admin_only'
  ) THEN
    CREATE POLICY "source_files_admin_only"
      ON storage.objects FOR ALL
      TO authenticated
      USING (
        bucket_id = 'buyweb-source-files' AND public.is_admin(auth.uid())
      )
      WITH CHECK (
        bucket_id = 'buyweb-source-files' AND public.is_admin(auth.uid())
      );
  END IF;
END $$;
