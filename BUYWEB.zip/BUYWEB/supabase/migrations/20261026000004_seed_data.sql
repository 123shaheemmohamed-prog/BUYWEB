-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Seed Data
-- Matches all 11 existing ready-made website templates from js/data.js
-- Prices stored in Paise (1 INR = 100 Paise)
-- ============================================================================

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Corporate Pro',
  'corporate-pro',
  'A sharp, professional corporate website designed for established businesses and service companies.',
  'Corporate Pro is a complete multi-page business website built for established companies, consulting firms, and professional service providers. It features a polished homepage, services section, team page, and contact form — all styled with a refined, authoritative aesthetic.',
  'business',
  'Frontend Template',
  1192000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript","Google Fonts"]'::jsonb,
  '["Homepage with hero, services overview, and CTA","Services page with individual service cards","About / Team page","Contact page with form"]'::jsonb,
  '["Responsive across desktop, tablet, and mobile","CSS-based animations (section reveals)","Working contact form (requires backend / email service)","Google Fonts integration","Sticky navigation with scroll behaviour","SEO-friendly HTML structure"]'::jsonb,
  TRUE,
  TRUE,
  'A web server or static hosting (Netlify, Vercel, GitHub Pages, cPanel). No database required.',
  'standard',
  'No backend or database included.
Contact form requires a third-party service (Formspree, EmailJS, or custom backend) to function.
Demo URL points to a placeholder until a live demo is configured.',
  'templates/corporate-pro-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Nexus Business',
  'nexus-business',
  'A clean, confident single-page business website. Fast, lightweight, ready to customise.',
  'Nexus Business is a streamlined single-page business website ideal for small businesses, freelancers, and local service providers. Everything is contained on one well-structured page, making it quick to launch and easy to update.',
  'business',
  'Frontend Template',
  712000,
  'INR',
  'Standard Website',
  '#',
  '["HTML5","CSS3","Vanilla JS"]'::jsonb,
  '["Single-page layout: Hero, Services, About, Contact"]'::jsonb,
  '["Fully responsive","Smooth scroll navigation","Contact form section (requires backend)","Lightweight — no JavaScript frameworks"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. No server-side requirements.',
  'standard',
  'Single-page only — additional pages require paid customisation.
Contact form requires a third-party email service.',
  'templates/nexus-business-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Folio Edge',
  'folio-edge',
  'A bold, editorial portfolio website for designers, photographers, and creative professionals.',
  'Folio Edge is a visually distinctive portfolio website built for creatives who want their work to lead. It features a fullscreen project grid, individual project detail pages, a biography section, and a contact form. The design uses generous whitespace and high-contrast typography to let the work speak.',
  'portfolio',
  'Frontend Template',
  1032000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — fullscreen hero and project grid","Project detail template (reusable)","About / Bio page","Contact page"]'::jsonb,
  '["Fullscreen hero section","Masonry-style project grid","Individual project detail layouts","Smooth page transitions (CSS)","Responsive on all devices","Optimised for visual content"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Replace project images and text content.',
  'standard',
  'No CMS. Content must be edited in HTML files.
Image optimisation is the responsibility of the buyer.',
  'templates/folio-edge-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Agency Noir',
  'agency-noir',
  'A premium dark-aesthetic agency website. Confident, editorial, built to win clients.',
  'Agency Noir is a sophisticated dark-mode agency website crafted for creative and digital agencies. It features an impactful hero, services overview, case studies section, team presentation, and client contact flow. The design communicates authority and craft.',
  'agency',
  'Frontend Template',
  1432000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript","Google Fonts"]'::jsonb,
  '["Homepage — full hero, services, case study previews","Services page — detailed service breakdowns","Work / Case Studies page — portfolio grid","About / Team page","Contact page"]'::jsonb,
  '["Dark editorial design system","Scroll-triggered section animations","Case study card grid","Service pricing presentation","Team grid section","Sticky header with scroll behaviour","Contact form (requires backend)"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. No database required.',
  'commercial',
  'Case studies are static HTML — a CMS is not included.
Contact form requires a third-party service.',
  'templates/agency-noir-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Bistro Luxe',
  'bistro-luxe',
  'An upscale restaurant website with menu presentation, gallery, and reservation form.',
  'Bistro Luxe is a warm, elegant restaurant website designed for fine dining, cafés, and food businesses. It features a rich hero, digital menu section with category tabs, photo gallery, and a reservation enquiry form. The design uses warm tones and refined typography to convey quality.',
  'restaurant',
  'Frontend Template',
  1272000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, story, highlights","Menu page — tabbed categories (Starters, Mains, Desserts, Drinks)","Gallery page","Reservations page — enquiry form","Contact / Location page"]'::jsonb,
  '["Tabbed menu navigation","Responsive image gallery","Reservation enquiry form (requires backend)","Location / map embed placeholder","Warm editorial typography","Full mobile responsiveness"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Map embed requires a Maps API key if used.',
  'standard',
  'No live reservation system. Form requires a backend or third-party booking service.
Map embed requires separate configuration.',
  'templates/bistro-luxe-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'ShopFront',
  'shopfront',
  'A complete e-commerce frontend with product catalogue, cart, and checkout UI.',
  'ShopFront is a fully designed e-commerce frontend template. It includes a product catalogue page, individual product detail view, shopping cart UI, and checkout form layout. The design is clean, conversion-focused, and responsive. Note: payment processing and order management require a separate backend or platform integration.',
  'ecommerce',
  'Frontend Template',
  2392000,
  'INR',
  'Advanced Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, featured products, categories","Product catalogue / shop page","Product detail page","Shopping cart page","Checkout page (UI only)","Order confirmation page (UI only)"]'::jsonb,
  '["Product catalogue with filter UI","Product detail pages with image gallery","Cart state managed via localStorage (JS)","Checkout form layout","Responsive on all devices","Category navigation"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting for the frontend. Payment processing and order management require a backend, payment API (Stripe, PayPal etc.), or an e-commerce platform.',
  'commercial',
  'No payment processing is included. This is a UI template only.
Cart uses localStorage — no server-side persistence.
Order management, inventory, and customer accounts require additional development or a platform.',
  'templates/shopfront-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Launchpad',
  'launchpad-saas',
  'A high-conversion SaaS landing page. Hero, features, pricing, FAQ, and CTA — done.',
  'Launchpad is a focused SaaS product landing page designed to communicate value and convert visitors. It includes a bold hero section, feature highlight blocks, a pricing table, testimonial placeholder, FAQ accordion, and a lead capture CTA. The design is dark, modern, and technically credible.',
  'saas',
  'Frontend Template',
  1512000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Single landing page: Hero, Features, Pricing, FAQ, CTA"]'::jsonb,
  '["Bold SaaS hero with headline and CTA","Feature highlight blocks (icon + text)","Three-tier pricing table","FAQ accordion (JavaScript)","Lead capture form section","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Lead capture form requires an email service or backend.',
  'commercial',
  'Landing page only — application UI is not included.
Lead capture requires a third-party service (Mailchimp, ConvertKit, etc.) or custom backend.',
  'templates/launchpad-saas-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Persona',
  'persona',
  'A refined personal brand website for speakers, consultants, coaches, and thought leaders.',
  'Persona is a clean, professional personal brand website designed for individuals who want to establish a credible online presence. It features a strong biography section, services or speaking topics overview, a curated selection of work or articles, and a contact form.',
  'personal',
  'Frontend Template',
  792000,
  'INR',
  'Standard Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, bio, services, featured work","About page — extended biography","Speaking / Services page","Contact page"]'::jsonb,
  '["Professional biography layout","Services / speaking topics section","Featured work or articles grid","Contact and enquiry form (requires backend)","Responsive on all devices"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting.',
  'standard',
  'Blog functionality is not included.
Contact form requires a backend or email service.',
  'templates/persona-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'EstatePro',
  'estatepro',
  'A premium real estate website with property listings, search UI, and agent profiles.',
  'EstatePro is a polished real estate frontend template with property listing cards, a search and filter UI, individual property detail pages, agent profiles, and an enquiry form. The design is clean, image-forward, and designed to showcase properties effectively.',
  'realestate',
  'Frontend Template',
  1752000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero search, featured listings","Listings page — grid with search and filter UI","Property detail page — images, specs, map placeholder","Agent / Team page","Contact page"]'::jsonb,
  '["Property listing grid with filter UI (client-side JS)","Property detail layout with image gallery","Search input and filter controls","Agent profile cards","Enquiry form (requires backend)","Map placeholder for property location","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Map embed requires a Maps API key. Backend required for dynamic listings.',
  'commercial',
  'Listings are static HTML. A dynamic listing system requires additional development.
Search and filter operate on the static content only.
Map embed requires a separate API configuration.',
  'templates/estatepro-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'LearnHub',
  'learnhub',
  'An inviting education website for schools, tutoring services, and online learning platforms.',
  'LearnHub is a clean, approachable education website designed for schools, tutoring centres, and educational brands. It features a welcoming hero, programme or course overview cards, instructor profiles, an events or schedule section, and an enrolment enquiry form.',
  'education',
  'Frontend Template',
  1352000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, highlights, courses overview","Courses / Programmes page","About / Instructors page","Events / Schedule page","Enrolment enquiry page"]'::jsonb,
  '["Course and programme cards","Instructor profile section","Events / schedule table layout","Enrolment enquiry form (requires backend)","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting.',
  'standard',
  'No LMS functionality. Online course delivery requires a separate platform.
Enrolment form requires backend configuration.',
  'templates/learnhub-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'IronFit',
  'ironfit',
  'A bold, high-energy fitness and gym website. Classes, trainers, memberships, and more.',
  'IronFit is a powerful, visually intense fitness website built for gyms, personal trainers, and fitness brands. It features a dramatic hero, class schedule section, trainer profiles, membership tier display, and a sign-up form. The design uses strong contrast and energetic typography.',
  'fitness',
  'Frontend Template',
  1192000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, key selling points, classes preview","Classes / Schedule page","Trainers page","Membership page","Contact / Sign-up page"]'::jsonb,
  '["High-impact hero section","Class schedule table / card layout","Trainer profile cards","Membership tier comparison","Sign-up enquiry form (requires backend)","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting.',
  'standard',
  'No booking or payment system. Online class booking requires additional development.
Membership management not included.',
  'templates/ironfit-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

