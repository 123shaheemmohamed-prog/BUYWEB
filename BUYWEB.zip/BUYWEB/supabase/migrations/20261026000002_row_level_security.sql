-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Schema Migration 02: Row Level Security (RLS)
-- ============================================================================
-- Enforces zero-trust database access control for public, customer, and admin
-- ============================================================================

-- 1. ENABLE ROW LEVEL SECURITY ON ALL TABLES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.licences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customization_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.download_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 2. COLUMN LEVEL PRIVILEGES FOR PRODUCTS
-- Ensure anonymous and regular authenticated users cannot select private file paths
REVOKE ALL ON public.products FROM anon, authenticated;
GRANT SELECT (
  id,
  name,
  slug,
  short_description,
  full_description,
  category,
  product_type,
  price,
  currency,
  package_tier,
  thumbnail_url,
  gallery_images,
  demo_url,
  technology_stack,
  included_pages,
  included_features,
  source_code_included,
  responsive_design,
  installation_instructions,
  licence_type,
  licence_terms,
  known_limitations,
  publication_status,
  featured,
  created_at,
  updated_at
) ON public.products TO anon, authenticated;

-- Service role and admin keep full access
GRANT ALL ON public.products TO service_role;
GRANT SELECT ON public.public_products TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PROFILES POLICIES
-- ----------------------------------------------------------------------------
-- Customers can view their own profile; admins can view all profiles
CREATE POLICY "profiles_select_owner_or_admin"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR public.is_admin(auth.uid())
  );

-- Users can insert their own profile matching auth.uid()
CREATE POLICY "profiles_insert_owner"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    id = auth.uid()
  );

-- Users can update only their own profile; role changes are blocked by trigger
CREATE POLICY "profiles_update_owner_or_admin"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR public.is_admin(auth.uid())
  )
  WITH CHECK (
    id = auth.uid() OR public.is_admin(auth.uid())
  );

-- Only admins can delete profiles
CREATE POLICY "profiles_delete_admin_only"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- PRODUCTS POLICIES
-- ----------------------------------------------------------------------------
-- Public visitors and authenticated users can view published products
CREATE POLICY "products_select_published_or_admin"
  ON public.products
  FOR SELECT
  TO public
  USING (
    publication_status = 'published' OR public.is_admin(auth.uid())
  );

-- Only admins can insert products
CREATE POLICY "products_insert_admin_only"
  ON public.products
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Only admins can update products
CREATE POLICY "products_update_admin_only"
  ON public.products
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Only admins can delete products
CREATE POLICY "products_delete_admin_only"
  ON public.products
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- ORDERS POLICIES
-- ----------------------------------------------------------------------------
-- Customers can only read their own orders; admins can read all orders
CREATE POLICY "orders_select_owner_or_admin"
  ON public.orders
  FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid() OR public.is_admin(auth.uid())
  );

-- Orders must be created through secure server Edge Functions (service_role) or admin
CREATE POLICY "orders_insert_admin_only"
  ON public.orders
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Customers cannot update orders directly
CREATE POLICY "orders_update_admin_only"
  ON public.orders
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "orders_delete_admin_only"
  ON public.orders
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- ORDER ITEMS POLICIES
-- ----------------------------------------------------------------------------
-- Customers can only read order items belonging to their own orders
CREATE POLICY "order_items_select_owner_or_admin"
  ON public.order_items
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = order_items.order_id
        AND (o.customer_id = auth.uid() OR public.is_admin(auth.uid()))
    )
  );

CREATE POLICY "order_items_insert_admin_only"
  ON public.order_items
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "order_items_update_admin_only"
  ON public.order_items
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "order_items_delete_admin_only"
  ON public.order_items
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- LICENCES POLICIES
-- ----------------------------------------------------------------------------
-- Customers can read licences issued to them
CREATE POLICY "licences_select_owner_or_admin"
  ON public.licences
  FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid() OR public.is_admin(auth.uid())
  );

CREATE POLICY "licences_insert_admin_only"
  ON public.licences
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "licences_update_admin_only"
  ON public.licences
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "licences_delete_admin_only"
  ON public.licences
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- CUSTOMIZATION REQUESTS POLICIES
-- ----------------------------------------------------------------------------
-- Customers can read their own requests; admins can read all
CREATE POLICY "customization_select_owner_or_admin"
  ON public.customization_requests
  FOR SELECT
  TO authenticated
  USING (
    (customer_id = auth.uid() AND auth.uid() IS NOT NULL) OR public.is_admin(auth.uid())
  );

-- Public visitors and customers can submit customization requests
CREATE POLICY "customization_insert_public"
  ON public.customization_requests
  FOR INSERT
  TO public
  WITH CHECK (
    customer_name IS NOT NULL AND length(trim(customer_name)) >= 2
    AND customer_email IS NOT NULL AND customer_email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
    AND requested_features IS NOT NULL AND length(trim(requested_features)) >= 3
    AND detailed_requirements IS NOT NULL AND length(trim(detailed_requirements)) >= 10
    AND (quoted_amount IS NULL) -- Customers cannot submit their own quotes
    AND (admin_notes IS NULL)   -- Customers cannot insert admin notes
    AND (status = 'new')        -- Initial status must be 'new'
  );

-- Only admins can update status, quote, or admin_notes
CREATE POLICY "customization_update_admin_only"
  ON public.customization_requests
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "customization_delete_admin_only"
  ON public.customization_requests
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- DOWNLOAD RECORDS POLICIES
-- ----------------------------------------------------------------------------
CREATE POLICY "downloads_select_owner_or_admin"
  ON public.download_records
  FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid() OR public.is_admin(auth.uid())
  );

CREATE POLICY "downloads_insert_admin_only"
  ON public.download_records
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "downloads_update_admin_only"
  ON public.download_records
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- PAYMENT EVENTS POLICIES
-- ----------------------------------------------------------------------------
-- Payment events contain sensitive gateway metadata; strictly admin only
CREATE POLICY "payment_events_admin_all"
  ON public.payment_events
  FOR ALL
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- AUDIT LOGS POLICIES
-- ----------------------------------------------------------------------------
CREATE POLICY "audit_logs_select_admin_only"
  ON public.audit_logs
  FOR SELECT
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

CREATE POLICY "audit_logs_insert_admin_or_server"
  ON public.audit_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Audit logs are strictly immutable: no updates or deletes permitted
CREATE POLICY "audit_logs_no_update"
  ON public.audit_logs
  FOR UPDATE
  TO authenticated
  USING (FALSE);

CREATE POLICY "audit_logs_no_delete"
  ON public.audit_logs
  FOR DELETE
  TO authenticated
  USING (FALSE);
