-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Schema Migration 01: Initial Schema
-- ============================================================================
-- Creates core tables, constraints, triggers, indexes, and helper functions
-- ============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. HELPER FUNCTIONS: Updated-at trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. PROFILES TABLE
-- Primary profile record linked 1:1 to auth.users.
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_profiles_email ON public.profiles(email);
CREATE INDEX idx_profiles_role ON public.profiles(role);

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Safe profile creation trigger from auth.users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    NEW.email,
    'customer' -- Always enforce customer role upon registration
  )
  ON CONFLICT (id) DO UPDATE
  SET email = EXCLUDED.email;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Attach trigger to auth.users (if permission allows in Supabase)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created') THEN
    DROP TRIGGER on_auth_user_created ON auth.users;
  END IF;
  CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Skipping direct trigger on auth.users if running outside Supabase hosted environment: %', SQLERRM;
END $$;

-- Role protection trigger: prevents regular users from elevating their role
CREATE OR REPLACE FUNCTION public.guard_profile_role_update()
RETURNS TRIGGER AS $$
DECLARE
  caller_role TEXT;
BEGIN
  -- If role is not changing, allow update
  IF NEW.role = OLD.role THEN
    RETURN NEW;
  END IF;

  -- Check if caller is admin
  SELECT role INTO caller_role FROM public.profiles WHERE id = auth.uid();
  IF caller_role = 'admin' THEN
    RETURN NEW;
  END IF;

  -- Disallow role alteration for non-admin callers
  RAISE EXCEPTION 'Unauthorized: Users cannot change account role.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER trg_profiles_guard_role
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.guard_profile_role_update();

-- Helper function: is_admin check for RLS
CREATE OR REPLACE FUNCTION public.is_admin(user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  IF user_id IS NULL THEN
    RETURN FALSE;
  END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = user_id AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- 4. PRODUCTS TABLE
-- Currency conversion note: Prices are stored as BIGINT in the smallest currency unit
-- (e.g. Paise for INR: ₹149.00 = 14900 paise, ₹11,999.00 = 1199900 paise; Cents for USD: $149 = 14900 cents)
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  short_description TEXT,
  full_description TEXT,
  category TEXT NOT NULL,
  product_type TEXT NOT NULL,
  price BIGINT NOT NULL CHECK (price >= 0),
  currency TEXT NOT NULL DEFAULT 'INR' CHECK (currency IN ('INR', 'USD', 'EUR', 'GBP')),
  package_tier TEXT,
  thumbnail_url TEXT,
  gallery_images JSONB DEFAULT '[]'::jsonb,
  demo_url TEXT,
  technology_stack JSONB DEFAULT '[]'::jsonb,
  included_pages JSONB DEFAULT '[]'::jsonb,
  included_features JSONB DEFAULT '[]'::jsonb,
  source_code_included BOOLEAN DEFAULT FALSE,
  responsive_design BOOLEAN DEFAULT TRUE,
  installation_instructions TEXT,
  licence_type TEXT DEFAULT 'standard',
  licence_terms TEXT,
  known_limitations TEXT,
  storage_file_path TEXT, -- Private path in buyweb-source-files bucket
  publication_status TEXT NOT NULL DEFAULT 'draft' CHECK (publication_status IN ('draft', 'published', 'archived')),
  featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_products_slug ON public.products(slug);
CREATE INDEX idx_products_category ON public.products(category);
CREATE INDEX idx_products_status ON public.products(publication_status);
CREATE INDEX idx_products_featured ON public.products(featured);

CREATE TRIGGER trg_products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Safe public view of products (hiding storage_file_path from public queries)
CREATE OR REPLACE VIEW public.public_products
WITH (security_invoker = true) AS
SELECT
  id,
  name,
  slug,
  short_description,
  full_description,
  category,
  product_type,
  price,
  currency,
  package_tier,
  thumbnail_url,
  gallery_images,
  demo_url,
  technology_stack,
  included_pages,
  included_features,
  source_code_included,
  responsive_design,
  installation_instructions,
  licence_type,
  licence_terms,
  known_limitations,
  publication_status,
  featured,
  created_at,
  updated_at
FROM public.products
WHERE publication_status = 'published';

-- 5. ORDERS TABLE
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  customer_email TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  subtotal BIGINT NOT NULL CHECK (subtotal >= 0),
  discount_amount BIGINT NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
  total_amount BIGINT NOT NULL CHECK (total_amount >= 0),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  order_status TEXT NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'processing', 'completed', 'cancelled', 'refunded')),
  payment_provider TEXT,
  provider_payment_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX idx_orders_number ON public.orders(order_number);
CREATE INDEX idx_orders_payment_status ON public.orders(payment_status);
CREATE INDEX idx_orders_created_at ON public.orders(created_at DESC);

CREATE TRIGGER trg_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Unique secure order number generator: BW-YYYYMMDD-XXXXX
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS TRIGGER AS $$
DECLARE
  date_prefix TEXT;
  random_suffix TEXT;
  new_order_num TEXT;
  exists_flag BOOLEAN;
BEGIN
  IF NEW.order_number IS NOT NULL AND NEW.order_number != '' THEN
    RETURN NEW;
  END IF;

  date_prefix := to_char(NOW(), 'YYYYMMDD');
  LOOP
    random_suffix := upper(substring(encode(gen_random_bytes(4), 'hex') from 1 for 5));
    new_order_num := 'BW-' || date_prefix || '-' || random_suffix;
    SELECT EXISTS (SELECT 1 FROM public.orders WHERE order_number = new_order_num) INTO exists_flag;
    EXIT WHEN NOT exists_flag;
  END LOOP;

  NEW.order_number := new_order_num;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_generate_number
  BEFORE INSERT ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_order_number();

-- Guard: Prevent unauthorized modification of total_amount and payment_status on orders
CREATE OR REPLACE FUNCTION public.guard_order_status_update()
RETURNS TRIGGER AS $$
BEGIN
  -- If caller is service_role or admin, allow
  IF current_user = 'service_role' OR public.is_admin(auth.uid()) THEN
    RETURN NEW;
  END IF;

  -- Customers cannot alter financial or status fields
  IF NEW.total_amount != OLD.total_amount OR
     NEW.subtotal != OLD.subtotal OR
     NEW.payment_status != OLD.payment_status OR
     NEW.order_status != OLD.order_status THEN
    RAISE EXCEPTION 'Unauthorized: Order totals and payment status can only be modified by server processes.';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER trg_orders_guard_status
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.guard_order_status_update();

-- 6. ORDER ITEMS TABLE
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  product_name_snapshot TEXT NOT NULL,
  licence_snapshot TEXT,
  unit_price BIGINT NOT NULL CHECK (unit_price >= 0),
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  line_total BIGINT NOT NULL CHECK (line_total >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX idx_order_items_product_id ON public.order_items(product_id);

-- 7. LICENCES TABLE
CREATE TABLE public.licences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id UUID NOT NULL REFERENCES public.order_items(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  licence_type TEXT NOT NULL,
  licence_version TEXT DEFAULT '1.0',
  terms_snapshot TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked')),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_licences_customer_id ON public.licences(customer_id);
CREATE INDEX idx_licences_order_item_id ON public.licences(order_item_id);

-- 8. CUSTOMIZATION REQUESTS TABLE
CREATE TABLE public.customization_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_reference TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  selected_product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  requested_features TEXT NOT NULL,
  detailed_requirements TEXT,
  budget_range TEXT,
  preferred_completion_date DATE,
  quoted_amount BIGINT CHECK (quoted_amount IS NULL OR quoted_amount >= 0),
  currency TEXT DEFAULT 'INR',
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_review', 'quoted', 'accepted', 'declined', 'completed')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customization_customer_id ON public.customization_requests(customer_id);
CREATE INDEX idx_customization_reference ON public.customization_requests(request_reference);
CREATE INDEX idx_customization_status ON public.customization_requests(status);

CREATE TRIGGER trg_customization_updated_at
  BEFORE UPDATE ON public.customization_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Reference generator: REQ-YYYYMMDD-XXXX
CREATE OR REPLACE FUNCTION public.generate_customization_reference()
RETURNS TRIGGER AS $$
DECLARE
  date_prefix TEXT;
  random_suffix TEXT;
  new_ref TEXT;
  exists_flag BOOLEAN;
BEGIN
  IF NEW.request_reference IS NOT NULL AND NEW.request_reference != '' THEN
    RETURN NEW;
  END IF;

  date_prefix := to_char(NOW(), 'YYYYMMDD');
  LOOP
    random_suffix := upper(substring(encode(gen_random_bytes(3), 'hex') from 1 for 4));
    new_ref := 'REQ-' || date_prefix || '-' || random_suffix;
    SELECT EXISTS (SELECT 1 FROM public.customization_requests WHERE request_reference = new_ref) INTO exists_flag;
    EXIT WHEN NOT exists_flag;
  END LOOP;

  NEW.request_reference := new_ref;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_customization_generate_ref
  BEFORE INSERT ON public.customization_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_customization_reference();

-- 9. DOWNLOAD RECORDS TABLE
CREATE TABLE public.download_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id UUID NOT NULL REFERENCES public.order_items(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  download_count INTEGER NOT NULL DEFAULT 0 CHECK (download_count >= 0),
  last_downloaded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_downloads_customer_id ON public.download_records(customer_id);
CREATE INDEX idx_downloads_order_item_id ON public.download_records(order_item_id);

-- 10. PAYMENT EVENTS TABLE
CREATE TABLE public.payment_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  processing_status TEXT NOT NULL DEFAULT 'pending' CHECK (processing_status IN ('pending', 'processed', 'ignored', 'failed')),
  payload JSONB,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  CONSTRAINT uq_payment_event UNIQUE (provider, provider_event_id)
);

CREATE INDEX idx_payment_events_status ON public.payment_events(processing_status);

-- 11. AUDIT LOGS TABLE
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_actor ON public.audit_logs(actor_id);
CREATE INDEX idx_audit_logs_target ON public.audit_logs(target_type, target_id);
CREATE INDEX idx_audit_logs_created_at ON public.audit_logs(created_at DESC);
