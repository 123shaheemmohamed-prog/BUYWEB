-- ============================================================================
-- BUYWEB — Optimize RLS Policies (Auth RLS Initialization Plan Fix)
-- ============================================================================
-- Wrapping auth.uid() in (select auth.uid()) prevents PostgreSQL from
-- evaluating auth.uid() on every row, optimizing performance from O(N) to O(1).
-- Run this in Supabase SQL Editor to clear all "Auth RLS Initialization Plan" warnings.
-- ============================================================================

-- 1. PROFILES POLICIES
DROP POLICY IF EXISTS "profiles_select_owner_or_admin" ON public.profiles;
CREATE POLICY "profiles_select_owner_or_admin"
  ON public.profiles FOR SELECT TO authenticated
  USING (id = (select auth.uid()) OR public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "profiles_insert_owner" ON public.profiles;
CREATE POLICY "profiles_insert_owner"
  ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (id = (select auth.uid()));

DROP POLICY IF EXISTS "profiles_update_owner_or_admin" ON public.profiles;
CREATE POLICY "profiles_update_owner_or_admin"
  ON public.profiles FOR UPDATE TO authenticated
  USING (id = (select auth.uid()) OR public.is_admin((select auth.uid())))
  WITH CHECK (id = (select auth.uid()) OR public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "profiles_delete_admin_only" ON public.profiles;
CREATE POLICY "profiles_delete_admin_only"
  ON public.profiles FOR DELETE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 2. PRODUCTS POLICIES
DROP POLICY IF EXISTS "products_select_published_or_admin" ON public.products;
CREATE POLICY "products_select_published_or_admin"
  ON public.products FOR SELECT TO public
  USING (publication_status = 'published' OR public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "products_insert_admin_only" ON public.products;
CREATE POLICY "products_insert_admin_only"
  ON public.products FOR INSERT TO authenticated
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "products_update_admin_only" ON public.products;
CREATE POLICY "products_update_admin_only"
  ON public.products FOR UPDATE TO authenticated
  USING (public.is_admin((select auth.uid())))
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "products_delete_admin_only" ON public.products;
CREATE POLICY "products_delete_admin_only"
  ON public.products FOR DELETE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 3. ORDERS POLICIES
DROP POLICY IF EXISTS "orders_select_owner_or_admin" ON public.orders;
CREATE POLICY "orders_select_owner_or_admin"
  ON public.orders FOR SELECT TO authenticated
  USING (customer_id = (select auth.uid()) OR public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "orders_insert_admin_only" ON public.orders;
CREATE POLICY "orders_insert_admin_only"
  ON public.orders FOR INSERT TO authenticated
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "orders_update_admin_only" ON public.orders;
CREATE POLICY "orders_update_admin_only"
  ON public.orders FOR UPDATE TO authenticated
  USING (public.is_admin((select auth.uid())))
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "orders_delete_admin_only" ON public.orders;
CREATE POLICY "orders_delete_admin_only"
  ON public.orders FOR DELETE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 4. ORDER ITEMS POLICIES
DROP POLICY IF EXISTS "order_items_select_owner_or_admin" ON public.order_items;
CREATE POLICY "order_items_select_owner_or_admin"
  ON public.order_items FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = order_items.order_id
        AND (o.customer_id = (select auth.uid()) OR public.is_admin((select auth.uid())))
    )
  );

DROP POLICY IF EXISTS "order_items_insert_admin_only" ON public.order_items;
CREATE POLICY "order_items_insert_admin_only"
  ON public.order_items FOR INSERT TO authenticated
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "order_items_update_admin_only" ON public.order_items;
CREATE POLICY "order_items_update_admin_only"
  ON public.order_items FOR UPDATE TO authenticated
  USING (public.is_admin((select auth.uid())))
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "order_items_delete_admin_only" ON public.order_items;
CREATE POLICY "order_items_delete_admin_only"
  ON public.order_items FOR DELETE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 5. LICENCES POLICIES
DROP POLICY IF EXISTS "licences_select_owner_or_admin" ON public.licences;
CREATE POLICY "licences_select_owner_or_admin"
  ON public.licences FOR SELECT TO authenticated
  USING (customer_id = (select auth.uid()) OR public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "licences_insert_admin_only" ON public.licences;
CREATE POLICY "licences_insert_admin_only"
  ON public.licences FOR INSERT TO authenticated
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "licences_update_admin_only" ON public.licences;
CREATE POLICY "licences_update_admin_only"
  ON public.licences FOR UPDATE TO authenticated
  USING (public.is_admin((select auth.uid())))
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "licences_delete_admin_only" ON public.licences;
CREATE POLICY "licences_delete_admin_only"
  ON public.licences FOR DELETE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 6. CUSTOMIZATION REQUESTS POLICIES
DROP POLICY IF EXISTS "customization_select_owner_or_admin" ON public.customization_requests;
CREATE POLICY "customization_select_owner_or_admin"
  ON public.customization_requests FOR SELECT TO authenticated
  USING (
    (customer_id = (select auth.uid()) AND (select auth.uid()) IS NOT NULL) OR public.is_admin((select auth.uid()))
  );

DROP POLICY IF EXISTS "customization_update_admin_only" ON public.customization_requests;
CREATE POLICY "customization_update_admin_only"
  ON public.customization_requests FOR UPDATE TO authenticated
  USING (public.is_admin((select auth.uid())))
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "customization_delete_admin_only" ON public.customization_requests;
CREATE POLICY "customization_delete_admin_only"
  ON public.customization_requests FOR DELETE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 7. DOWNLOAD RECORDS POLICIES
DROP POLICY IF EXISTS "download_records_select_owner_or_admin" ON public.download_records;
CREATE POLICY "download_records_select_owner_or_admin"
  ON public.download_records FOR SELECT TO authenticated
  USING (customer_id = (select auth.uid()) OR public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "download_records_insert_admin_only" ON public.download_records;
CREATE POLICY "download_records_insert_admin_only"
  ON public.download_records FOR INSERT TO authenticated
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "download_records_update_admin_only" ON public.download_records;
CREATE POLICY "download_records_update_admin_only"
  ON public.download_records FOR UPDATE TO authenticated
  USING (public.is_admin((select auth.uid())));

-- 8. PAYMENT EVENTS & AUDIT LOGS POLICIES
DROP POLICY IF EXISTS "payment_events_admin_only" ON public.payment_events;
CREATE POLICY "payment_events_admin_only"
  ON public.payment_events FOR ALL TO authenticated
  USING (public.is_admin((select auth.uid())))
  WITH CHECK (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "audit_logs_select_admin_only" ON public.audit_logs;
CREATE POLICY "audit_logs_select_admin_only"
  ON public.audit_logs FOR SELECT TO authenticated
  USING (public.is_admin((select auth.uid())));

DROP POLICY IF EXISTS "audit_logs_insert_service_or_admin" ON public.audit_logs;
CREATE POLICY "audit_logs_insert_service_or_admin"
  ON public.audit_logs FOR INSERT TO authenticated
  WITH CHECK (public.is_admin((select auth.uid())));
