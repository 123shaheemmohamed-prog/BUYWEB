import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient, getAuthenticatedUser } from '../_shared/supabaseClient.ts';

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const user = await getAuthenticatedUser(req);
    if (!user) {
      return new Response(JSON.stringify({ error: 'Authentication required.' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = getAdminClient();

    // Verify admin role
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (!profile || profile.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Access forbidden: Administrator privileges required.' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { action } = body;

    // 1. GET ANALYTICS: Computed strictly from real database records
    if (action === 'get-analytics') {
      const { data: orders } = await supabase
        .from('orders')
        .select('id, order_number, total_amount, currency, payment_status, order_status, created_at, customer_email');

      const allOrders = orders || [];
      let grossSales = 0;
      let refundedAmount = 0;
      let paidCount = 0;
      let pendingCount = 0;

      for (const ord of allOrders) {
        if (ord.payment_status === 'paid') {
          grossSales += Number(ord.total_amount);
          paidCount++;
        } else if (ord.payment_status === 'refunded') {
          refundedAmount += Number(ord.total_amount);
        } else if (ord.payment_status === 'pending') {
          pendingCount++;
        }
      }

      const netSales = grossSales - refundedAmount;

      const { count: totalProducts } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true });

      const { count: publishedProducts } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true })
        .eq('publication_status', 'published');

      const { count: totalEnquiries } = await supabase
        .from('customization_requests')
        .select('*', { count: 'exact', head: true });

      const { count: newEnquiries } = await supabase
        .from('customization_requests')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'new');

      return new Response(JSON.stringify({
        success: true,
        analytics: {
          grossSales, // in paise
          refundedAmount,
          netSales,
          totalOrders: allOrders.length,
          paidOrders: paidCount,
          pendingOrders: pendingCount,
          totalProducts: totalProducts || 0,
          publishedProducts: publishedProducts || 0,
          totalEnquiries: totalEnquiries || 0,
          newEnquiries: newEnquiries || 0,
          currency: 'INR',
        },
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 2. UPDATE CUSTOMIZATION QUOTE
    if (action === 'quote-customization') {
      const { requestId, quotedAmount, adminNotes, status = 'quoted' } = body;
      if (!requestId) {
        return new Response(JSON.stringify({ error: 'Missing requestId.' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { error: quoteErr } = await supabase
        .from('customization_requests')
        .update({
          quoted_amount: quotedAmount,
          admin_notes: adminNotes,
          status: status,
        })
        .eq('id', requestId);

      if (quoteErr) throw new Error(quoteErr.message);

      return new Response(JSON.stringify({ success: true, message: 'Customization quote updated.' }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: `Unknown action '${action}'` }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
