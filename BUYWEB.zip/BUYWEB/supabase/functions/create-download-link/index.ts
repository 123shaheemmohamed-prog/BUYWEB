import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient, getAuthenticatedUser } from '../_shared/supabaseClient.ts';

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    // 1. Authenticate requesting customer
    const user = await getAuthenticatedUser(req);
    if (!user) {
      return new Response(JSON.stringify({ error: 'Authentication required to access download.' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { orderItemId } = body;

    if (!orderItemId) {
      return new Response(JSON.stringify({ error: 'Missing orderItemId.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = getAdminClient();

    // 2. Fetch order item and corresponding order and product
    const { data: item, error: itemError } = await supabase
      .from('order_items')
      .select(`
        id,
        order_id,
        product_id,
        product_name_snapshot,
        orders (
          id,
          customer_id,
          payment_status,
          order_status
        ),
        products (
          id,
          name,
          storage_file_path,
          publication_status
        )
      `)
      .eq('id', orderItemId)
      .single();

    if (itemError || !item) {
      return new Response(JSON.stringify({ error: 'Order item not found.' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const order = item.orders as any;
    const product = item.products as any;

    // 3. Verify Customer Ownership
    if (!order || order.customer_id !== user.id) {
      return new Response(JSON.stringify({ error: 'Access denied: You do not own this purchase.' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 4. Verify Payment Status
    if (order.payment_status !== 'paid' || order.order_status === 'refunded' || order.order_status === 'cancelled') {
      return new Response(JSON.stringify({
        error: `Download unavailable: Order payment status is '${order.payment_status}' and order status is '${order.order_status}'.`,
      }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 5. Confirm that the purchased product includes a downloadable file
    const filePath = product?.storage_file_path;
    if (!filePath) {
      return new Response(JSON.stringify({
        error: 'Product downloadable archive is currently being prepared. Please contact support.',
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 6. Check download limits & active licence
    const { data: licence } = await supabase
      .from('licences')
      .select('status')
      .eq('order_item_id', item.id)
      .maybeSingle();

    if (licence && licence.status !== 'active') {
      return new Response(JSON.stringify({ error: `Licence is ${licence.status}. Download access is revoked.` }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 7. Generate a short-lived signed URL (60 seconds) for private storage object
    const { data: signedData, error: signedError } = await supabase
      .storage
      .from('buyweb-source-files')
      .createSignedUrl(filePath, 60); // 60 seconds expiry

    if (signedError || !signedData?.signedUrl) {
      throw new Error(`Failed to generate signed download URL: ${signedError?.message || 'Storage error'}`);
    }

    // 8. Record download event
    const { data: existingRec } = await supabase
      .from('download_records')
      .select('id, download_count')
      .eq('order_item_id', item.id)
      .maybeSingle();

    if (existingRec) {
      await supabase
        .from('download_records')
        .update({
          download_count: (existingRec.download_count || 0) + 1,
          last_downloaded_at: new Date().toISOString(),
        })
        .eq('id', existingRec.id);
    } else {
      await supabase
        .from('download_records')
        .insert({
          order_item_id: item.id,
          customer_id: user.id,
          download_count: 1,
          last_downloaded_at: new Date().toISOString(),
        });
    }

    // 9. Log audit entry
    await supabase.from('audit_logs').insert({
      actor_id: user.id,
      action: 'DOWNLOAD_LINK_GENERATED',
      target_type: 'order_items',
      target_id: item.id,
      metadata: {
        productName: item.product_name_snapshot,
        expiresInSeconds: 60,
      },
    });

    // 10. Return temporary download URL
    return new Response(JSON.stringify({
      success: true,
      downloadUrl: signedData.signedUrl,
      expiresIn: 60,
      productName: item.product_name_snapshot,
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
