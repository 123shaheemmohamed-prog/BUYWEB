import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient, getAuthenticatedUser } from '../_shared/supabaseClient.ts';

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const user = await getAuthenticatedUser(req);
    if (!user) {
      return new Response(JSON.stringify({ error: 'Authentication required.' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = getAdminClient();

    // Verify administrator role
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (!profile || profile.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Access forbidden: Administrator privileges required.' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const body = await req.json();
    const { orderId, reason } = body;

    if (!orderId) {
      return new Response(JSON.stringify({ error: 'Missing orderId.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*, order_items(*)')
      .eq('id', orderId)
      .single();

    if (orderError || !order) {
      return new Response(JSON.stringify({ error: 'Order not found.' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (order.payment_status !== 'paid') {
      return new Response(JSON.stringify({ error: `Cannot refund order with payment status '${order.payment_status}'.` }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const razorpayKeyId = Deno.env.get('RAZORPAY_KEY_ID');
    const razorpayKeySecret = Deno.env.get('RAZORPAY_KEY_SECRET');
    let refundReference = null;

    if (razorpayKeyId && razorpayKeySecret && order.provider_payment_reference) {
      const authHeader = 'Basic ' + btoa(`${razorpayKeyId}:${razorpayKeySecret}`);
      const refundUrl = `https://api.razorpay.com/v1/payments/${order.provider_payment_reference}/refund`;
      const refundRes = await fetch(refundUrl, {
        method: 'POST',
        headers: {
          'Authorization': authHeader,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          notes: {
            order_id: order.id,
            reason: reason || 'Customer refund requested',
          },
        }),
      });

      if (!refundRes.ok) {
        const errorText = await refundRes.text();
        throw new Error(`Payment gateway refund failed: ${errorText}`);
      }

      const refundData = await refundRes.json();
      refundReference = refundData.id;
    }

    // Update order status to refunded
    await supabase
      .from('orders')
      .update({
        payment_status: 'refunded',
        order_status: 'refunded',
      })
      .eq('id', order.id);

    // Revoke corresponding licences
    if (order.order_items) {
      const itemIds = order.order_items.map((i: any) => i.id);
      await supabase
        .from('licences')
        .update({ status: 'revoked' })
        .in('order_item_id', itemIds);
    }

    // Record audit log
    await supabase.from('audit_logs').insert({
      actor_id: user.id,
      action: 'ORDER_REFUNDED',
      target_type: 'orders',
      target_id: order.id,
      metadata: {
        orderNumber: order.order_number,
        amount: order.total_amount,
        reason: reason || 'Manual admin refund',
        refundReference,
      },
    });

    return new Response(JSON.stringify({
      success: true,
      message: `Order #${order.order_number} refunded and associated licences revoked successfully.`,
      refundReference,
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
