import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient, getAuthenticatedUser } from '../_shared/supabaseClient.ts';

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json();
    const {
      name,
      email,
      website, // product slug or id
      feature,
      requirements,
      budget,
      preferredDate,
    } = body;

    // Validation
    const trimmedName = (name || '').trim();
    const trimmedEmail = (email || '').trim();
    const trimmedFeature = (feature || '').trim();
    const trimmedRequirements = (requirements || '').trim();

    if (!trimmedName || trimmedName.length < 2) {
      return new Response(JSON.stringify({ error: 'Name must be at least 2 characters.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!trimmedEmail || !emailRegex.test(trimmedEmail)) {
      return new Response(JSON.stringify({ error: 'Please provide a valid email address.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!trimmedFeature || trimmedFeature.length < 3) {
      return new Response(JSON.stringify({ error: 'Please describe the requested feature or change.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!trimmedRequirements || trimmedRequirements.length < 10) {
      return new Response(JSON.stringify({ error: 'Requirements must be at least 10 characters.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const authUser = await getAuthenticatedUser(req);
    const supabase = getAdminClient();

    // Find product id if selected
    let selectedProductId = null;
    if (website && website !== 'other') {
      const { data: prod } = await supabase
        .from('products')
        .select('id')
        .or(`id.eq.${website},slug.eq.${website}`)
        .maybeSingle();

      if (prod) selectedProductId = prod.id;
    }

    // Insert customization request
    const { data: request, error: insertError } = await supabase
      .from('customization_requests')
      .insert({
        customer_id: authUser ? authUser.id : null,
        customer_name: trimmedName,
        customer_email: trimmedEmail,
        selected_product_id: selectedProductId,
        requested_features: trimmedFeature,
        detailed_requirements: trimmedRequirements,
        budget_range: budget || null,
        preferred_completion_date: preferredDate || null,
        status: 'new',
      })
      .select('id, request_reference, created_at')
      .single();

    if (insertError || !request) {
      throw new Error(`Failed to save customization request: ${insertError?.message}`);
    }

    // Optional email confirmation
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    if (resendApiKey) {
      try {
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${resendApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from: 'BUYWEB Customizations <support@buyweb.dev>',
            to: [trimmedEmail],
            subject: `Customization Enquiry Received — Ref #${request.request_reference}`,
            html: `
              <h3>Thank you for reaching out, ${trimmedName}!</h3>
              <p>We have received your customization enquiry under reference <strong>#${request.request_reference}</strong>.</p>
              <p><strong>Requested Feature:</strong> ${trimmedFeature}</p>
              <p>Our engineering team evaluates each request individually. If approved, we will provide a separate quotation and delivery schedule for your review.</p>
              <br/>
              <p>Note: No extra work begins until scope and pricing are agreed in writing.</p>
            `,
          }),
        });
      } catch (emailErr) {
        console.error('Failed to send confirmation email:', emailErr);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      reference: request.request_reference,
      message: 'Customization enquiry submitted successfully.',
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
