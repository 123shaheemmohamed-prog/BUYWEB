import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

export function getAdminClient() {
  const supabaseUrl = Deno.env.get('SUPABASE_URL') || 'https://emnrouupsgrcprcvmups.supabase.co';
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in environment.');
  }

  return createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}

export function getUserClient(authHeader: string | null) {
  const supabaseUrl = Deno.env.get('SUPABASE_URL') || 'https://emnrouupsgrcprcvmups.supabase.co';
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || 'sb_publishable_V5LFhTlAsDzhOQkvAixHkQ_rpNJeo54';

  return createClient(supabaseUrl, anonKey, {
    global: {
      headers: authHeader ? { Authorization: authHeader } : {},
    },
    auth: {
      persistSession: false,
    },
  });
}

export async function getAuthenticatedUser(req: Request) {
  const authHeader = req.headers.get('Authorization');
  if (!authHeader) return null;

  try {
    const userClient = getUserClient(authHeader);
    const { data: { user }, error } = await userClient.auth.getUser();
    if (error || !user) return null;
    return user;
  } catch (_e) {
    return null;
  }
}
