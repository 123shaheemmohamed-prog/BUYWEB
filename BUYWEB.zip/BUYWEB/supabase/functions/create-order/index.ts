import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient, getAuthenticatedUser } from '../_shared/supabaseClient.ts';

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json();
    const { productId, customerEmail, customerName, licenceType = 'standard' } = body;

    if (!productId) {
      return new Response(JSON.stringify({ error: 'Product identifier is required.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Authenticate user if token provided
    const authUser = await getAuthenticatedUser(req);
    const customerId = authUser ? authUser.id : null;
    const finalEmail = authUser ? authUser.email : (customerEmail || '').trim();

    if (!finalEmail) {
      return new Response(JSON.stringify({ error: 'Customer email is required.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = getAdminClient();

    // 1. Fetch current product price & details from PostgreSQL (Never trust frontend price)
    const { data: product, error: productError } = await supabase
      .from('products')
      .select('*')
      .or(`id.eq.${productId},slug.eq.${productId}`)
      .eq('publication_status', 'published')
      .single();

    if (productError || !product) {
      return new Response(JSON.stringify({ error: 'Product not found or not published.' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 2. Server-side price calculation
    let unitPrice = Number(product.price);
    if (licenceType === 'commercial') {
      // Commercial licence tier: 1.5x of base standard price
      unitPrice = Math.round(unitPrice * 1.5);
    }

    const quantity = 1;
    const subtotal = unitPrice * quantity;
    const discountAmount = 0;
    const totalAmount = subtotal;
    const currency = product.currency || 'INR';

    // 3. Create Pending Order in database
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .insert({
        customer_id: customerId,
        customer_email: finalEmail,
        currency: currency,
        subtotal: subtotal,
        discount_amount: discountAmount,
        total_amount: totalAmount,
        payment_status: 'pending',
        order_status: 'pending',
        payment_provider: 'razorpay',
      })
      .select()
      .single();

    if (orderError || !order) {
      throw new Error(`Failed to create order record: ${orderError?.message}`);
    }

    // 4. Create Order Item snapshot
    const licenceSnapshot = licenceType === 'commercial'
      ? 'Commercial Licence - Permits one commercial end product. Modifications allowed. Redistribution prohibited.'
      : 'Standard Licence - Permits one end product for personal or commercial use. Modifications allowed. Redistribution prohibited.';

    const { error: itemError } = await supabase
      .from('order_items')
      .insert({
        order_id: order.id,
        product_id: product.id,
        product_name_snapshot: product.name,
        licence_snapshot: licenceSnapshot,
        unit_price: unitPrice,
        quantity: quantity,
        line_total: totalAmount,
      });

    if (itemError) {
      throw new Error(`Failed to create order item: ${itemError.message}`);
    }

    // 5. Connect to Payment Gateway (Razorpay)
    const razorpayKeyId = Deno.env.get('RAZORPAY_KEY_ID');
    const razorpayKeySecret = Deno.env.get('RAZORPAY_KEY_SECRET');

    let providerOrderId = null;

    if (razorpayKeyId && razorpayKeySecret) {
      const authHeader = 'Basic ' + btoa(`${razorpayKeyId}:${razorpayKeySecret}`);
      const rzpResponse = await fetch('https://api.razorpay.com/v1/orders', {
        method: 'POST',
        headers: {
          'Authorization': authHeader,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: totalAmount,
          currency: currency,
          receipt: order.order_number,
          notes: {
            order_id: order.id,
            product_id: product.id,
            product_name: product.name,
          },
        }),
      });

      if (!rzpResponse.ok) {
        const errorText = await rzpResponse.text();
        throw new Error(`Razorpay order creation failed: ${errorText}`);
      }

      const rzpData = await rzpResponse.json();
      providerOrderId = rzpData.id;

      // Update order with provider reference
      await supabase
        .from('orders')
        .update({ provider_payment_reference: providerOrderId })
        .eq('id', order.id);
    }

    return new Response(
      JSON.stringify({
        success: true,
        orderId: order.id,
        orderNumber: order.order_number,
        amount: totalAmount,
        currency: currency,
        razorpayOrderId: providerOrderId,
        razorpayKeyId: razorpayKeyId || null,
        pendingGatewayConfig: !razorpayKeyId,
        product: {
          id: product.id,
          name: product.name,
          licenceType: licenceType,
        },
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
