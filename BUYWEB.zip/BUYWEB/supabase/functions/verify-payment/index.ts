import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient } from '../_shared/supabaseClient.ts';

async function verifyRazorpaySignature(
  orderId: string,
  paymentId: string,
  signature: string,
  secret: string
): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    const data = encoder.encode(`${orderId}|${paymentId}`);
    const signatureBytes = await crypto.subtle.sign('HMAC', key, data);
    const hashHex = Array.from(new Uint8Array(signatureBytes))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    return hashHex.toLowerCase() === signature.toLowerCase();
  } catch (_e) {
    return false;
  }
}

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json();
    const {
      orderId,
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature,
    } = body;

    if (!orderId || !razorpayPaymentId) {
      return new Response(JSON.stringify({ error: 'Missing payment verification details.' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const supabase = getAdminClient();
    const secret = Deno.env.get('RAZORPAY_KEY_SECRET');

    // 1. Fetch internal order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('*, order_items(*)')
      .eq('id', orderId)
      .single();

    if (orderError || !order) {
      return new Response(JSON.stringify({ error: 'Order not found.' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Idempotency: If already paid, return success immediately
    if (order.payment_status === 'paid') {
      return new Response(JSON.stringify({
        success: true,
        alreadyProcessed: true,
        orderNumber: order.order_number,
        message: 'Order has already been confirmed and paid.',
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 2. Cryptographic Signature Verification
    if (secret && razorpaySignature && razorpayOrderId) {
      const isValid = await verifyRazorpaySignature(
        razorpayOrderId,
        razorpayPaymentId,
        razorpaySignature,
        secret
      );

      if (!isValid) {
        // Record failed attempt
        await supabase.from('payment_events').insert({
          provider: 'razorpay',
          provider_event_id: razorpayPaymentId,
          event_type: 'payment.signature_verification_failed',
          processing_status: 'failed',
          payload: { orderId, razorpayOrderId, razorpayPaymentId },
        });

        return new Response(JSON.stringify({ error: 'Invalid payment signature. Verification failed.' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    } else if (!secret) {
      // In development / pre-configuration mode when gateway credentials are not yet supplied
      return new Response(JSON.stringify({
        error: 'Payment gateway secret not configured on server. Please set RAZORPAY_KEY_SECRET in Supabase secrets.',
      }), {
        status: 503,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // 3. Update Order Status in Database
    const { error: updateError } = await supabase
      .from('orders')
      .update({
        payment_status: 'paid',
        order_status: 'completed',
        provider_payment_reference: razorpayPaymentId,
      })
      .eq('id', order.id);

    if (updateError) {
      throw new Error(`Failed to update order status: ${updateError.message}`);
    }

    // 4. Issue Licences and Initialize Download Records
    if (order.order_items && order.order_items.length > 0) {
      for (const item of order.order_items) {
        if (order.customer_id) {
          // Create Licence record
          await supabase.from('licences').insert({
            order_item_id: item.id,
            customer_id: order.customer_id,
            licence_type: item.licence_snapshot?.includes('Commercial') ? 'commercial' : 'standard',
            licence_version: '1.0',
            terms_snapshot: item.licence_snapshot,
            status: 'active',
          });

          // Create Download Record
          await supabase.from('download_records').insert({
            order_item_id: item.id,
            customer_id: order.customer_id,
            download_count: 0,
          });
        }
      }
    }

    // 5. Record Payment Event
    await supabase.from('payment_events').insert({
      provider: 'razorpay',
      provider_event_id: razorpayPaymentId,
      event_type: 'payment.verified',
      processing_status: 'processed',
      payload: {
        orderId: order.id,
        orderNumber: order.order_number,
        amount: order.total_amount,
        currency: order.currency,
        razorpayOrderId,
        razorpayPaymentId,
      },
      processed_at: new Date().toISOString(),
    });

    // 6. Record Audit Log
    await supabase.from('audit_logs').insert({
      actor_id: order.customer_id,
      action: 'PAYMENT_VERIFIED',
      target_type: 'orders',
      target_id: order.id,
      metadata: {
        orderNumber: order.order_number,
        paymentReference: razorpayPaymentId,
        amount: order.total_amount,
      },
    });

    // 7. Transactional Email Notification (Resend)
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    if (resendApiKey && order.customer_email) {
      try {
        await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${resendApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from: 'BUYWEB Orders <orders@buyweb.dev>',
            to: [order.customer_email],
            subject: `Payment Confirmed — Order #${order.order_number}`,
            html: `
              <h2>Thank you for your purchase from BUYWEB!</h2>
              <p>Your payment for order <strong>#${order.order_number}</strong> has been successfully verified.</p>
              <p>Total: ${(order.total_amount / 100).toLocaleString('en-IN', { style: 'currency', currency: order.currency })}</p>
              <p>Your template files and licences are now available in your BUYWEB Account portal.</p>
              <br/>
              <p>— The BUYWEB Team</p>
            `,
          }),
        });
      } catch (emailErr) {
        console.error('Failed to send confirmation email:', emailErr);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      orderNumber: order.order_number,
      message: 'Payment verified and order fulfilled successfully.',
    }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message || 'Server error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
