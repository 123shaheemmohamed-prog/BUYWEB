import { corsHeaders, handleCors } from '../_shared/cors.ts';
import { getAdminClient } from '../_shared/supabaseClient.ts';

async function verifyWebhookSignature(
  rawBody: string,
  signature: string,
  secret: string
): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    const signatureBytes = await crypto.subtle.sign('HMAC', key, encoder.encode(rawBody));
    const hashHex = Array.from(new Uint8Array(signatureBytes))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
    return hashHex.toLowerCase() === signature.toLowerCase();
  } catch (_e) {
    return false;
  }
}

Deno.serve(async (req: Request) => {
  const corsResponse = handleCors(req);
  if (corsResponse) return corsResponse;

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const rawBody = await req.text();
  const signature = req.headers.get('x-razorpay-signature') || '';
  const webhookSecret = Deno.env.get('RAZORPAY_WEBHOOK_SECRET');

  if (!webhookSecret) {
    return new Response(JSON.stringify({ error: 'Webhook secret not configured.' }), {
      status: 503,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Cryptographic webhook signature verification
  const isValid = await verifyWebhookSignature(rawBody, signature, webhookSecret);
  if (!isValid) {
    return new Response(JSON.stringify({ error: 'Invalid webhook signature.' }), {
      status: 401,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  let eventData: any;
  try {
    eventData = JSON.parse(rawBody);
  } catch (_e) {
    return new Response(JSON.stringify({ error: 'Invalid JSON payload.' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const supabase = getAdminClient();
  const eventId = eventData.event_id || eventData.payload?.payment?.entity?.id || `evt_${Date.now()}`;
  const eventType = eventData.event || 'unknown';

  // 1. Idempotency Check: Prevent duplicate webhook processing
  const { data: existingEvent } = await supabase
    .from('payment_events')
    .select('id, processing_status')
    .eq('provider', 'razorpay')
    .eq('provider_event_id', eventId)
    .maybeSingle();

  if (existingEvent && existingEvent.processing_status === 'processed') {
    return new Response(JSON.stringify({ message: 'Event already processed.' }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Record initial event
  if (!existingEvent) {
    await supabase.from('payment_events').insert({
      provider: 'razorpay',
      provider_event_id: eventId,
      event_type: eventType,
      processing_status: 'pending',
      payload: eventData,
    });
  }

  try {
    const paymentEntity = eventData.payload?.payment?.entity;
    const internalOrderId = paymentEntity?.notes?.order_id;
    const paymentId = paymentEntity?.id;

    if (eventType === 'payment.captured' && internalOrderId) {
      const { data: order } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('id', internalOrderId)
        .single();

      if (order && order.payment_status !== 'paid') {
        // Mark order as paid
        await supabase
          .from('orders')
          .update({
            payment_status: 'paid',
            order_status: 'completed',
            provider_payment_reference: paymentId,
          })
          .eq('id', order.id);

        // Issue licences and download records if not already present
        if (order.order_items) {
          for (const item of order.order_items) {
            if (order.customer_id) {
              await supabase.from('licences').upsert({
                order_item_id: item.id,
                customer_id: order.customer_id,
                licence_type: item.licence_snapshot?.includes('Commercial') ? 'commercial' : 'standard',
                licence_version: '1.0',
                terms_snapshot: item.licence_snapshot,
                status: 'active',
              });

              await supabase.from('download_records').upsert({
                order_item_id: item.id,
                customer_id: order.customer_id,
                download_count: 0,
              });
            }
          }
        }
      }
    } else if (eventType === 'payment.failed' && internalOrderId) {
      await supabase
        .from('orders')
        .update({ payment_status: 'failed', order_status: 'cancelled' })
        .eq('id', internalOrderId);
    } else if (eventType === 'refund.processed') {
      const refundEntity = eventData.payload?.refund?.entity;
      const refPaymentId = refundEntity?.payment_id;

      if (refPaymentId) {
        const { data: order } = await supabase
          .from('orders')
          .select('id, customer_id')
          .eq('provider_payment_reference', refPaymentId)
          .maybeSingle();

        if (order) {
          await supabase
            .from('orders')
            .update({ payment_status: 'refunded', order_status: 'refunded' })
            .eq('id', order.id);

          // Revoke customer licences for this order
          const { data: items } = await supabase
            .from('order_items')
            .select('id')
            .eq('order_id', order.id);

          if (items) {
            const itemIds = items.map((i: any) => i.id);
            await supabase
              .from('licences')
              .update({ status: 'revoked' })
              .in('order_item_id', itemIds);
          }
        }
      }
    }

    // Mark event as processed
    await supabase
      .from('payment_events')
      .update({
        processing_status: 'processed',
        processed_at: new Date().toISOString(),
      })
      .eq('provider', 'razorpay')
      .eq('provider_event_id', eventId);

    return new Response(JSON.stringify({ success: true, eventId }), {
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (procErr: any) {
    await supabase
      .from('payment_events')
      .update({ processing_status: 'failed' })
      .eq('provider', 'razorpay')
      .eq('provider_event_id', eventId);

    return new Response(JSON.stringify({ error: procErr.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
