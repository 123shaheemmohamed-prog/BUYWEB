-- ============================================================================
-- BUYWEB — Complete Database Setup Script
-- Paste and run this script in Supabase Studio -> SQL Editor -> New Query -> Run
-- Project: https://emnrouupsgrcprcvmups.supabase.co
-- ============================================================================



-- ============================================================================
-- SECTION: supabase/migrations/20261026000001_initial_schema.sql
-- ============================================================================

-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Schema Migration 01: Initial Schema
-- ============================================================================
-- Creates core tables, constraints, triggers, indexes, and helper functions
-- ============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. HELPER FUNCTIONS: Updated-at trigger function
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. PROFILES TABLE
-- Primary profile record linked 1:1 to auth.users.
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_profiles_email ON public.profiles(email);
CREATE INDEX idx_profiles_role ON public.profiles(role);

CREATE TRIGGER trg_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Safe profile creation trigger from auth.users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    NEW.email,
    'customer' -- Always enforce customer role upon registration
  )
  ON CONFLICT (id) DO UPDATE
  SET email = EXCLUDED.email;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Attach trigger to auth.users (if permission allows in Supabase)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'on_auth_user_created') THEN
    DROP TRIGGER on_auth_user_created ON auth.users;
  END IF;
  CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Skipping direct trigger on auth.users if running outside Supabase hosted environment: %', SQLERRM;
END $$;

-- Role protection trigger: prevents regular users from elevating their role
CREATE OR REPLACE FUNCTION public.guard_profile_role_update()
RETURNS TRIGGER AS $$
DECLARE
  caller_role TEXT;
BEGIN
  -- If role is not changing, allow update
  IF NEW.role = OLD.role THEN
    RETURN NEW;
  END IF;

  -- Check if caller is admin
  SELECT role INTO caller_role FROM public.profiles WHERE id = auth.uid();
  IF caller_role = 'admin' THEN
    RETURN NEW;
  END IF;

  -- Disallow role alteration for non-admin callers
  RAISE EXCEPTION 'Unauthorized: Users cannot change account role.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER trg_profiles_guard_role
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.guard_profile_role_update();

-- Helper function: is_admin check for RLS
CREATE OR REPLACE FUNCTION public.is_admin(user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  IF user_id IS NULL THEN
    RETURN FALSE;
  END IF;
  RETURN EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = user_id AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public;

-- 4. PRODUCTS TABLE
-- Currency conversion note: Prices are stored as BIGINT in the smallest currency unit
-- (e.g. Paise for INR: ₹149.00 = 14900 paise, ₹11,999.00 = 1199900 paise; Cents for USD: $149 = 14900 cents)
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  short_description TEXT,
  full_description TEXT,
  category TEXT NOT NULL,
  product_type TEXT NOT NULL,
  price BIGINT NOT NULL CHECK (price >= 0),
  currency TEXT NOT NULL DEFAULT 'INR' CHECK (currency IN ('INR', 'USD', 'EUR', 'GBP')),
  package_tier TEXT,
  thumbnail_url TEXT,
  gallery_images JSONB DEFAULT '[]'::jsonb,
  demo_url TEXT,
  technology_stack JSONB DEFAULT '[]'::jsonb,
  included_pages JSONB DEFAULT '[]'::jsonb,
  included_features JSONB DEFAULT '[]'::jsonb,
  source_code_included BOOLEAN DEFAULT FALSE,
  responsive_design BOOLEAN DEFAULT TRUE,
  installation_instructions TEXT,
  licence_type TEXT DEFAULT 'standard',
  licence_terms TEXT,
  known_limitations TEXT,
  storage_file_path TEXT, -- Private path in buyweb-source-files bucket
  publication_status TEXT NOT NULL DEFAULT 'draft' CHECK (publication_status IN ('draft', 'published', 'archived')),
  featured BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_products_slug ON public.products(slug);
CREATE INDEX idx_products_category ON public.products(category);
CREATE INDEX idx_products_status ON public.products(publication_status);
CREATE INDEX idx_products_featured ON public.products(featured);

CREATE TRIGGER trg_products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Safe public view of products (hiding storage_file_path from public queries)
CREATE OR REPLACE VIEW public.public_products
WITH (security_invoker = true) AS
SELECT
  id,
  name,
  slug,
  short_description,
  full_description,
  category,
  product_type,
  price,
  currency,
  package_tier,
  thumbnail_url,
  gallery_images,
  demo_url,
  technology_stack,
  included_pages,
  included_features,
  source_code_included,
  responsive_design,
  installation_instructions,
  licence_type,
  licence_terms,
  known_limitations,
  publication_status,
  featured,
  created_at,
  updated_at
FROM public.products
WHERE publication_status = 'published';

-- 5. ORDERS TABLE
CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  customer_email TEXT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'INR',
  subtotal BIGINT NOT NULL CHECK (subtotal >= 0),
  discount_amount BIGINT NOT NULL DEFAULT 0 CHECK (discount_amount >= 0),
  total_amount BIGINT NOT NULL CHECK (total_amount >= 0),
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  order_status TEXT NOT NULL DEFAULT 'pending' CHECK (order_status IN ('pending', 'processing', 'completed', 'cancelled', 'refunded')),
  payment_provider TEXT,
  provider_payment_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_orders_customer_id ON public.orders(customer_id);
CREATE INDEX idx_orders_number ON public.orders(order_number);
CREATE INDEX idx_orders_payment_status ON public.orders(payment_status);
CREATE INDEX idx_orders_created_at ON public.orders(created_at DESC);

CREATE TRIGGER trg_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Unique secure order number generator: BW-YYYYMMDD-XXXXX
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS TRIGGER AS $$
DECLARE
  date_prefix TEXT;
  random_suffix TEXT;
  new_order_num TEXT;
  exists_flag BOOLEAN;
BEGIN
  IF NEW.order_number IS NOT NULL AND NEW.order_number != '' THEN
    RETURN NEW;
  END IF;

  date_prefix := to_char(NOW(), 'YYYYMMDD');
  LOOP
    random_suffix := upper(substring(encode(gen_random_bytes(4), 'hex') from 1 for 5));
    new_order_num := 'BW-' || date_prefix || '-' || random_suffix;
    SELECT EXISTS (SELECT 1 FROM public.orders WHERE order_number = new_order_num) INTO exists_flag;
    EXIT WHEN NOT exists_flag;
  END LOOP;

  NEW.order_number := new_order_num;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_generate_number
  BEFORE INSERT ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_order_number();

-- Guard: Prevent unauthorized modification of total_amount and payment_status on orders
CREATE OR REPLACE FUNCTION public.guard_order_status_update()
RETURNS TRIGGER AS $$
BEGIN
  -- If caller is service_role or admin, allow
  IF current_user = 'service_role' OR public.is_admin(auth.uid()) THEN
    RETURN NEW;
  END IF;

  -- Customers cannot alter financial or status fields
  IF NEW.total_amount != OLD.total_amount OR
     NEW.subtotal != OLD.subtotal OR
     NEW.payment_status != OLD.payment_status OR
     NEW.order_status != OLD.order_status THEN
    RAISE EXCEPTION 'Unauthorized: Order totals and payment status can only be modified by server processes.';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER trg_orders_guard_status
  BEFORE UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.guard_order_status_update();

-- 6. ORDER ITEMS TABLE
CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  product_name_snapshot TEXT NOT NULL,
  licence_snapshot TEXT,
  unit_price BIGINT NOT NULL CHECK (unit_price >= 0),
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  line_total BIGINT NOT NULL CHECK (line_total >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_order_items_order_id ON public.order_items(order_id);
CREATE INDEX idx_order_items_product_id ON public.order_items(product_id);

-- 7. LICENCES TABLE
CREATE TABLE public.licences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id UUID NOT NULL REFERENCES public.order_items(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  licence_type TEXT NOT NULL,
  licence_version TEXT DEFAULT '1.0',
  terms_snapshot TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'revoked')),
  issued_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_licences_customer_id ON public.licences(customer_id);
CREATE INDEX idx_licences_order_item_id ON public.licences(order_item_id);

-- 8. CUSTOMIZATION REQUESTS TABLE
CREATE TABLE public.customization_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_reference TEXT UNIQUE NOT NULL,
  customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  selected_product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
  requested_features TEXT NOT NULL,
  detailed_requirements TEXT,
  budget_range TEXT,
  preferred_completion_date DATE,
  quoted_amount BIGINT CHECK (quoted_amount IS NULL OR quoted_amount >= 0),
  currency TEXT DEFAULT 'INR',
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_review', 'quoted', 'accepted', 'declined', 'completed')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customization_customer_id ON public.customization_requests(customer_id);
CREATE INDEX idx_customization_reference ON public.customization_requests(request_reference);
CREATE INDEX idx_customization_status ON public.customization_requests(status);

CREATE TRIGGER trg_customization_updated_at
  BEFORE UPDATE ON public.customization_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Reference generator: REQ-YYYYMMDD-XXXX
CREATE OR REPLACE FUNCTION public.generate_customization_reference()
RETURNS TRIGGER AS $$
DECLARE
  date_prefix TEXT;
  random_suffix TEXT;
  new_ref TEXT;
  exists_flag BOOLEAN;
BEGIN
  IF NEW.request_reference IS NOT NULL AND NEW.request_reference != '' THEN
    RETURN NEW;
  END IF;

  date_prefix := to_char(NOW(), 'YYYYMMDD');
  LOOP
    random_suffix := upper(substring(encode(gen_random_bytes(3), 'hex') from 1 for 4));
    new_ref := 'REQ-' || date_prefix || '-' || random_suffix;
    SELECT EXISTS (SELECT 1 FROM public.customization_requests WHERE request_reference = new_ref) INTO exists_flag;
    EXIT WHEN NOT exists_flag;
  END LOOP;

  NEW.request_reference := new_ref;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_customization_generate_ref
  BEFORE INSERT ON public.customization_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_customization_reference();

-- 9. DOWNLOAD RECORDS TABLE
CREATE TABLE public.download_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_item_id UUID NOT NULL REFERENCES public.order_items(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  download_count INTEGER NOT NULL DEFAULT 0 CHECK (download_count >= 0),
  last_downloaded_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_downloads_customer_id ON public.download_records(customer_id);
CREATE INDEX idx_downloads_order_item_id ON public.download_records(order_item_id);

-- 10. PAYMENT EVENTS TABLE
CREATE TABLE public.payment_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  processing_status TEXT NOT NULL DEFAULT 'pending' CHECK (processing_status IN ('pending', 'processed', 'ignored', 'failed')),
  payload JSONB,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  CONSTRAINT uq_payment_event UNIQUE (provider, provider_event_id)
);

CREATE INDEX idx_payment_events_status ON public.payment_events(processing_status);

-- 11. AUDIT LOGS TABLE
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_actor ON public.audit_logs(actor_id);
CREATE INDEX idx_audit_logs_target ON public.audit_logs(target_type, target_id);
CREATE INDEX idx_audit_logs_created_at ON public.audit_logs(created_at DESC);


-- ============================================================================
-- SECTION: supabase/migrations/20261026000002_row_level_security.sql
-- ============================================================================

-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Schema Migration 02: Row Level Security (RLS)
-- ============================================================================
-- Enforces zero-trust database access control for public, customer, and admin
-- ============================================================================

-- 1. ENABLE ROW LEVEL SECURITY ON ALL TABLES
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.licences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customization_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.download_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- 2. COLUMN LEVEL PRIVILEGES FOR PRODUCTS
-- Ensure anonymous and regular authenticated users cannot select private file paths
REVOKE ALL ON public.products FROM anon, authenticated;
GRANT SELECT (
  id,
  name,
  slug,
  short_description,
  full_description,
  category,
  product_type,
  price,
  currency,
  package_tier,
  thumbnail_url,
  gallery_images,
  demo_url,
  technology_stack,
  included_pages,
  included_features,
  source_code_included,
  responsive_design,
  installation_instructions,
  licence_type,
  licence_terms,
  known_limitations,
  publication_status,
  featured,
  created_at,
  updated_at
) ON public.products TO anon, authenticated;

-- Service role and admin keep full access
GRANT ALL ON public.products TO service_role;
GRANT SELECT ON public.public_products TO anon, authenticated;

-- ----------------------------------------------------------------------------
-- PROFILES POLICIES
-- ----------------------------------------------------------------------------
-- Customers can view their own profile; admins can view all profiles
CREATE POLICY "profiles_select_owner_or_admin"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR public.is_admin(auth.uid())
  );

-- Users can insert their own profile matching auth.uid()
CREATE POLICY "profiles_insert_owner"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    id = auth.uid()
  );

-- Users can update only their own profile; role changes are blocked by trigger
CREATE POLICY "profiles_update_owner_or_admin"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR public.is_admin(auth.uid())
  )
  WITH CHECK (
    id = auth.uid() OR public.is_admin(auth.uid())
  );

-- Only admins can delete profiles
CREATE POLICY "profiles_delete_admin_only"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- PRODUCTS POLICIES
-- ----------------------------------------------------------------------------
-- Public visitors and authenticated users can view published products
CREATE POLICY "products_select_published_or_admin"
  ON public.products
  FOR SELECT
  TO public
  USING (
    publication_status = 'published' OR public.is_admin(auth.uid())
  );

-- Only admins can insert products
CREATE POLICY "products_insert_admin_only"
  ON public.products
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Only admins can update products
CREATE POLICY "products_update_admin_only"
  ON public.products
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Only admins can delete products
CREATE POLICY "products_delete_admin_only"
  ON public.products
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- ORDERS POLICIES
-- ----------------------------------------------------------------------------
-- Customers can only read their own orders; admins can read all orders
CREATE POLICY "orders_select_owner_or_admin"
  ON public.orders
  FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid() OR public.is_admin(auth.uid())
  );

-- Orders must be created through secure server Edge Functions (service_role) or admin
CREATE POLICY "orders_insert_admin_only"
  ON public.orders
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Customers cannot update orders directly
CREATE POLICY "orders_update_admin_only"
  ON public.orders
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "orders_delete_admin_only"
  ON public.orders
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- ORDER ITEMS POLICIES
-- ----------------------------------------------------------------------------
-- Customers can only read order items belonging to their own orders
CREATE POLICY "order_items_select_owner_or_admin"
  ON public.order_items
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.orders o
      WHERE o.id = order_items.order_id
        AND (o.customer_id = auth.uid() OR public.is_admin(auth.uid()))
    )
  );

CREATE POLICY "order_items_insert_admin_only"
  ON public.order_items
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "order_items_update_admin_only"
  ON public.order_items
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "order_items_delete_admin_only"
  ON public.order_items
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- LICENCES POLICIES
-- ----------------------------------------------------------------------------
-- Customers can read licences issued to them
CREATE POLICY "licences_select_owner_or_admin"
  ON public.licences
  FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid() OR public.is_admin(auth.uid())
  );

CREATE POLICY "licences_insert_admin_only"
  ON public.licences
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "licences_update_admin_only"
  ON public.licences
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "licences_delete_admin_only"
  ON public.licences
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- CUSTOMIZATION REQUESTS POLICIES
-- ----------------------------------------------------------------------------
-- Customers can read their own requests; admins can read all
CREATE POLICY "customization_select_owner_or_admin"
  ON public.customization_requests
  FOR SELECT
  TO authenticated
  USING (
    (customer_id = auth.uid() AND auth.uid() IS NOT NULL) OR public.is_admin(auth.uid())
  );

-- Public visitors and customers can submit customization requests
CREATE POLICY "customization_insert_public"
  ON public.customization_requests
  FOR INSERT
  TO public
  WITH CHECK (
    customer_name IS NOT NULL AND length(trim(customer_name)) >= 2
    AND customer_email IS NOT NULL AND customer_email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
    AND requested_features IS NOT NULL AND length(trim(requested_features)) >= 3
    AND detailed_requirements IS NOT NULL AND length(trim(detailed_requirements)) >= 10
    AND (quoted_amount IS NULL) -- Customers cannot submit their own quotes
    AND (admin_notes IS NULL)   -- Customers cannot insert admin notes
    AND (status = 'new')        -- Initial status must be 'new'
  );

-- Only admins can update status, quote, or admin_notes
CREATE POLICY "customization_update_admin_only"
  ON public.customization_requests
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "customization_delete_admin_only"
  ON public.customization_requests
  FOR DELETE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- DOWNLOAD RECORDS POLICIES
-- ----------------------------------------------------------------------------
CREATE POLICY "downloads_select_owner_or_admin"
  ON public.download_records
  FOR SELECT
  TO authenticated
  USING (
    customer_id = auth.uid() OR public.is_admin(auth.uid())
  );

CREATE POLICY "downloads_insert_admin_only"
  ON public.download_records
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

CREATE POLICY "downloads_update_admin_only"
  ON public.download_records
  FOR UPDATE
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- PAYMENT EVENTS POLICIES
-- ----------------------------------------------------------------------------
-- Payment events contain sensitive gateway metadata; strictly admin only
CREATE POLICY "payment_events_admin_all"
  ON public.payment_events
  FOR ALL
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  )
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- ----------------------------------------------------------------------------
-- AUDIT LOGS POLICIES
-- ----------------------------------------------------------------------------
CREATE POLICY "audit_logs_select_admin_only"
  ON public.audit_logs
  FOR SELECT
  TO authenticated
  USING (
    public.is_admin(auth.uid())
  );

CREATE POLICY "audit_logs_insert_admin_or_server"
  ON public.audit_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
  );

-- Audit logs are strictly immutable: no updates or deletes permitted
CREATE POLICY "audit_logs_no_update"
  ON public.audit_logs
  FOR UPDATE
  TO authenticated
  USING (FALSE);

CREATE POLICY "audit_logs_no_delete"
  ON public.audit_logs
  FOR DELETE
  TO authenticated
  USING (FALSE);


-- ============================================================================
-- SECTION: supabase/migrations/20261026000003_storage_buckets.sql
-- ============================================================================

-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Schema Migration 03: Storage Buckets & Policies
-- ============================================================================
-- Configures public preview bucket and private source-files bucket with RLS
-- ============================================================================

-- 1. INSERT BUCKETS
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES
  (
    'buyweb-previews',
    'buyweb-previews',
    true,
    5242880, -- 5 MB limit for preview images
    ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml']::text[]
  ),
  (
    'buyweb-source-files',
    'buyweb-source-files',
    false, -- Strictly PRIVATE bucket
    52428800, -- 50 MB limit for template zip packages
    ARRAY['application/zip', 'application/x-zip-compressed', 'application/octet-stream']::text[]
  )
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- 2. STORAGE POLICIES FOR buyweb-previews (Public read, admin write)
DO $$
BEGIN
  -- Select policy for public previews
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'previews_public_read'
  ) THEN
    CREATE POLICY "previews_public_read"
      ON storage.objects FOR SELECT
      TO public
      USING (bucket_id = 'buyweb-previews');
  END IF;

  -- Admin upload for previews
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'previews_admin_insert'
  ) THEN
    CREATE POLICY "previews_admin_insert"
      ON storage.objects FOR INSERT
      TO authenticated
      WITH CHECK (
        bucket_id = 'buyweb-previews' AND public.is_admin(auth.uid())
      );
  END IF;

  -- Admin update/delete for previews
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'previews_admin_manage'
  ) THEN
    CREATE POLICY "previews_admin_manage"
      ON storage.objects FOR ALL
      TO authenticated
      USING (
        bucket_id = 'buyweb-previews' AND public.is_admin(auth.uid())
      );
  END IF;

  -- 3. STORAGE POLICIES FOR buyweb-source-files (Private, strictly admin upload, NO public select)
  -- Note: Customer downloads are handled exclusively through server-side signed URLs created with service_role.
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'source_files_admin_only'
  ) THEN
    CREATE POLICY "source_files_admin_only"
      ON storage.objects FOR ALL
      TO authenticated
      USING (
        bucket_id = 'buyweb-source-files' AND public.is_admin(auth.uid())
      )
      WITH CHECK (
        bucket_id = 'buyweb-source-files' AND public.is_admin(auth.uid())
      );
  END IF;
END $$;


-- ============================================================================
-- SECTION: supabase/migrations/20261026000004_seed_data.sql
-- ============================================================================

-- ============================================================================
-- BUYWEB - Supabase PostgreSQL Seed Data
-- Matches all 11 existing ready-made website templates from js/data.js
-- Prices stored in Paise (1 INR = 100 Paise)
-- ============================================================================

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Corporate Pro',
  'corporate-pro',
  'A sharp, professional corporate website designed for established businesses and service companies.',
  'Corporate Pro is a complete multi-page business website built for established companies, consulting firms, and professional service providers. It features a polished homepage, services section, team page, and contact form — all styled with a refined, authoritative aesthetic.',
  'business',
  'Frontend Template',
  1192000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript","Google Fonts"]'::jsonb,
  '["Homepage with hero, services overview, and CTA","Services page with individual service cards","About / Team page","Contact page with form"]'::jsonb,
  '["Responsive across desktop, tablet, and mobile","CSS-based animations (section reveals)","Working contact form (requires backend / email service)","Google Fonts integration","Sticky navigation with scroll behaviour","SEO-friendly HTML structure"]'::jsonb,
  TRUE,
  TRUE,
  'A web server or static hosting (Netlify, Vercel, GitHub Pages, cPanel). No database required.',
  'standard',
  'No backend or database included.
Contact form requires a third-party service (Formspree, EmailJS, or custom backend) to function.
Demo URL points to a placeholder until a live demo is configured.',
  'templates/corporate-pro-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Nexus Business',
  'nexus-business',
  'A clean, confident single-page business website. Fast, lightweight, ready to customise.',
  'Nexus Business is a streamlined single-page business website ideal for small businesses, freelancers, and local service providers. Everything is contained on one well-structured page, making it quick to launch and easy to update.',
  'business',
  'Frontend Template',
  712000,
  'INR',
  'Standard Website',
  '#',
  '["HTML5","CSS3","Vanilla JS"]'::jsonb,
  '["Single-page layout: Hero, Services, About, Contact"]'::jsonb,
  '["Fully responsive","Smooth scroll navigation","Contact form section (requires backend)","Lightweight — no JavaScript frameworks"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. No server-side requirements.',
  'standard',
  'Single-page only — additional pages require paid customisation.
Contact form requires a third-party email service.',
  'templates/nexus-business-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Folio Edge',
  'folio-edge',
  'A bold, editorial portfolio website for designers, photographers, and creative professionals.',
  'Folio Edge is a visually distinctive portfolio website built for creatives who want their work to lead. It features a fullscreen project grid, individual project detail pages, a biography section, and a contact form. The design uses generous whitespace and high-contrast typography to let the work speak.',
  'portfolio',
  'Frontend Template',
  1032000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — fullscreen hero and project grid","Project detail template (reusable)","About / Bio page","Contact page"]'::jsonb,
  '["Fullscreen hero section","Masonry-style project grid","Individual project detail layouts","Smooth page transitions (CSS)","Responsive on all devices","Optimised for visual content"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Replace project images and text content.',
  'standard',
  'No CMS. Content must be edited in HTML files.
Image optimisation is the responsibility of the buyer.',
  'templates/folio-edge-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Agency Noir',
  'agency-noir',
  'A premium dark-aesthetic agency website. Confident, editorial, built to win clients.',
  'Agency Noir is a sophisticated dark-mode agency website crafted for creative and digital agencies. It features an impactful hero, services overview, case studies section, team presentation, and client contact flow. The design communicates authority and craft.',
  'agency',
  'Frontend Template',
  1432000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript","Google Fonts"]'::jsonb,
  '["Homepage — full hero, services, case study previews","Services page — detailed service breakdowns","Work / Case Studies page — portfolio grid","About / Team page","Contact page"]'::jsonb,
  '["Dark editorial design system","Scroll-triggered section animations","Case study card grid","Service pricing presentation","Team grid section","Sticky header with scroll behaviour","Contact form (requires backend)"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. No database required.',
  'commercial',
  'Case studies are static HTML — a CMS is not included.
Contact form requires a third-party service.',
  'templates/agency-noir-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Bistro Luxe',
  'bistro-luxe',
  'An upscale restaurant website with menu presentation, gallery, and reservation form.',
  'Bistro Luxe is a warm, elegant restaurant website designed for fine dining, cafés, and food businesses. It features a rich hero, digital menu section with category tabs, photo gallery, and a reservation enquiry form. The design uses warm tones and refined typography to convey quality.',
  'restaurant',
  'Frontend Template',
  1272000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, story, highlights","Menu page — tabbed categories (Starters, Mains, Desserts, Drinks)","Gallery page","Reservations page — enquiry form","Contact / Location page"]'::jsonb,
  '["Tabbed menu navigation","Responsive image gallery","Reservation enquiry form (requires backend)","Location / map embed placeholder","Warm editorial typography","Full mobile responsiveness"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Map embed requires a Maps API key if used.',
  'standard',
  'No live reservation system. Form requires a backend or third-party booking service.
Map embed requires separate configuration.',
  'templates/bistro-luxe-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'ShopFront',
  'shopfront',
  'A complete e-commerce frontend with product catalogue, cart, and checkout UI.',
  'ShopFront is a fully designed e-commerce frontend template. It includes a product catalogue page, individual product detail view, shopping cart UI, and checkout form layout. The design is clean, conversion-focused, and responsive. Note: payment processing and order management require a separate backend or platform integration.',
  'ecommerce',
  'Frontend Template',
  2392000,
  'INR',
  'Advanced Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, featured products, categories","Product catalogue / shop page","Product detail page","Shopping cart page","Checkout page (UI only)","Order confirmation page (UI only)"]'::jsonb,
  '["Product catalogue with filter UI","Product detail pages with image gallery","Cart state managed via localStorage (JS)","Checkout form layout","Responsive on all devices","Category navigation"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting for the frontend. Payment processing and order management require a backend, payment API (Stripe, PayPal etc.), or an e-commerce platform.',
  'commercial',
  'No payment processing is included. This is a UI template only.
Cart uses localStorage — no server-side persistence.
Order management, inventory, and customer accounts require additional development or a platform.',
  'templates/shopfront-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Launchpad',
  'launchpad-saas',
  'A high-conversion SaaS landing page. Hero, features, pricing, FAQ, and CTA — done.',
  'Launchpad is a focused SaaS product landing page designed to communicate value and convert visitors. It includes a bold hero section, feature highlight blocks, a pricing table, testimonial placeholder, FAQ accordion, and a lead capture CTA. The design is dark, modern, and technically credible.',
  'saas',
  'Frontend Template',
  1512000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Single landing page: Hero, Features, Pricing, FAQ, CTA"]'::jsonb,
  '["Bold SaaS hero with headline and CTA","Feature highlight blocks (icon + text)","Three-tier pricing table","FAQ accordion (JavaScript)","Lead capture form section","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Lead capture form requires an email service or backend.',
  'commercial',
  'Landing page only — application UI is not included.
Lead capture requires a third-party service (Mailchimp, ConvertKit, etc.) or custom backend.',
  'templates/launchpad-saas-source-v1.0.zip',
  'published',
  TRUE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'Persona',
  'persona',
  'A refined personal brand website for speakers, consultants, coaches, and thought leaders.',
  'Persona is a clean, professional personal brand website designed for individuals who want to establish a credible online presence. It features a strong biography section, services or speaking topics overview, a curated selection of work or articles, and a contact form.',
  'personal',
  'Frontend Template',
  792000,
  'INR',
  'Standard Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, bio, services, featured work","About page — extended biography","Speaking / Services page","Contact page"]'::jsonb,
  '["Professional biography layout","Services / speaking topics section","Featured work or articles grid","Contact and enquiry form (requires backend)","Responsive on all devices"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting.',
  'standard',
  'Blog functionality is not included.
Contact form requires a backend or email service.',
  'templates/persona-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'EstatePro',
  'estatepro',
  'A premium real estate website with property listings, search UI, and agent profiles.',
  'EstatePro is a polished real estate frontend template with property listing cards, a search and filter UI, individual property detail pages, agent profiles, and an enquiry form. The design is clean, image-forward, and designed to showcase properties effectively.',
  'realestate',
  'Frontend Template',
  1752000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero search, featured listings","Listings page — grid with search and filter UI","Property detail page — images, specs, map placeholder","Agent / Team page","Contact page"]'::jsonb,
  '["Property listing grid with filter UI (client-side JS)","Property detail layout with image gallery","Search input and filter controls","Agent profile cards","Enquiry form (requires backend)","Map placeholder for property location","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting. Map embed requires a Maps API key. Backend required for dynamic listings.',
  'commercial',
  'Listings are static HTML. A dynamic listing system requires additional development.
Search and filter operate on the static content only.
Map embed requires a separate API configuration.',
  'templates/estatepro-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'LearnHub',
  'learnhub',
  'An inviting education website for schools, tutoring services, and online learning platforms.',
  'LearnHub is a clean, approachable education website designed for schools, tutoring centres, and educational brands. It features a welcoming hero, programme or course overview cards, instructor profiles, an events or schedule section, and an enrolment enquiry form.',
  'education',
  'Frontend Template',
  1352000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, highlights, courses overview","Courses / Programmes page","About / Instructors page","Events / Schedule page","Enrolment enquiry page"]'::jsonb,
  '["Course and programme cards","Instructor profile section","Events / schedule table layout","Enrolment enquiry form (requires backend)","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting.',
  'standard',
  'No LMS functionality. Online course delivery requires a separate platform.
Enrolment form requires backend configuration.',
  'templates/learnhub-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';

INSERT INTO public.products (
  name, slug, short_description, full_description, category, product_type,
  price, currency, package_tier, demo_url, technology_stack, included_pages,
  included_features, source_code_included, responsive_design,
  installation_instructions, licence_type, known_limitations,
  storage_file_path, publication_status, featured
) VALUES (
  'IronFit',
  'ironfit',
  'A bold, high-energy fitness and gym website. Classes, trainers, memberships, and more.',
  'IronFit is a powerful, visually intense fitness website built for gyms, personal trainers, and fitness brands. It features a dramatic hero, class schedule section, trainer profiles, membership tier display, and a sign-up form. The design uses strong contrast and energetic typography.',
  'fitness',
  'Frontend Template',
  1192000,
  'INR',
  'Premium Website',
  '#',
  '["HTML5","CSS3","JavaScript"]'::jsonb,
  '["Homepage — hero, key selling points, classes preview","Classes / Schedule page","Trainers page","Membership page","Contact / Sign-up page"]'::jsonb,
  '["High-impact hero section","Class schedule table / card layout","Trainer profile cards","Membership tier comparison","Sign-up enquiry form (requires backend)","Fully responsive"]'::jsonb,
  TRUE,
  TRUE,
  'Static hosting.',
  'standard',
  'No booking or payment system. Online class booking requires additional development.
Membership management not included.',
  'templates/ironfit-source-v1.0.zip',
  'published',
  FALSE
) ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  short_description = EXCLUDED.short_description,
  full_description = EXCLUDED.full_description,
  category = EXCLUDED.category,
  price = EXCLUDED.price,
  publication_status = 'published';



-- ============================================================================
-- HELPER FUNCTION: create_customer_order (Enables client order creation with RLS)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.create_customer_order(
  p_product_id UUID,
  p_licence_type TEXT DEFAULT 'standard'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id UUID;
  v_user_email TEXT;
  v_product RECORD;
  v_unit_price BIGINT;
  v_order_id UUID;
  v_order_number TEXT;
  v_licence_snapshot TEXT;
  v_currency TEXT;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Authentication required to place an order.';
  END IF;

  SELECT email INTO v_user_email FROM auth.users WHERE id = v_user_id;

  SELECT * INTO v_product FROM public.products
  WHERE id = p_product_id AND publication_status = 'published';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Product not found or not published.';
  END IF;

  v_unit_price := v_product.price;
  IF p_licence_type = 'commercial' THEN
    v_unit_price := ROUND(v_unit_price * 1.5);
  END IF;

  v_currency := COALESCE(v_product.currency, 'INR');

  INSERT INTO public.orders (
    customer_id,
    customer_email,
    currency,
    subtotal,
    discount_amount,
    total_amount,
    payment_status,
    order_status,
    payment_provider
  ) VALUES (
    v_user_id,
    v_user_email,
    v_currency,
    v_unit_price,
    0,
    v_unit_price,
    'pending',
    'pending',
    'razorpay'
  ) RETURNING id, order_number INTO v_order_id, v_order_number;

  IF p_licence_type = 'commercial' THEN
    v_licence_snapshot := 'Commercial Licence - Permits one commercial end product. Modifications allowed. Redistribution prohibited.';
  ELSE
    v_licence_snapshot := 'Standard Licence - Permits one end product for personal or commercial use. Modifications allowed. Redistribution prohibited.';
  END IF;

  INSERT INTO public.order_items (
    order_id,
    product_id,
    product_name_snapshot,
    licence_snapshot,
    unit_price,
    quantity,
    line_total
  ) VALUES (
    v_order_id,
    v_product.id,
    v_product.name,
    v_licence_snapshot,
    v_unit_price,
    1,
    v_unit_price
  );

  RETURN jsonb_build_object(
    'orderId', v_order_id,
    'orderNumber', v_order_number,
    'amount', v_unit_price,
    'currency', v_currency,
    'licenceType', p_licence_type,
    'productName', v_product.name
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_customer_order(UUID, TEXT) TO authenticated;
