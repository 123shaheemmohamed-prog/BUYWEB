# BUYWEB — Premium Ready-Made Website Store

**Founded by Mohamed Shaheem**  
Tagline: *Choose. Purchase. Launch.*

---

## Overview

BUYWEB is a premium ready-made website store. The business model is built around:

1. Creating ready-made websites in advance
2. Displaying finished website demos in an online store
3. Selling the same website template to multiple customers under clearly defined licence terms
4. Providing included source code and documentation
5. Charging additional fees for optional customisation, extra features, and modifications

---

## Project Structure

```
BUYWEB/
├── index.html                  Main homepage (store, sections, contact)
├── pages/
│   └── legal.html              Terms, Licence, Privacy, Refund, Customisation Policy
├── css/
│   ├── tokens.css              Design system tokens (colours, typography, spacing)
│   ├── base.css                CSS reset and base element styles
│   ├── components.css          Reusable components (buttons, badges, forms, toasts)
│   ├── layout.css              Header, footer, container, nav
│   ├── hero.css                Hero section styles
│   ├── store.css               Product store and card styles
│   ├── sections.css            Content sections (How It Works, About, Contact, etc.)
│   ├── modal.css               Product detail modal
│   └── responsive.css          Responsive breakpoints
└── js/
    ├── data.js                 Product catalogue data (edit to add/update products)
    ├── store.js                Store engine — renders cards, search, filter, sort
    ├── modal.js                Product detail modal controller
    ├── form.js                 Contact form validation
    ├── nav.js                  Navigation behaviour
    └── main.js                 Initialisation, animations, utilities
```

---

## Adding or Editing Products

All products are defined in [`js/data.js`](js/data.js).

Each product object has:
| Field | Description |
|---|---|
| `id` | Unique kebab-case identifier |
| `name` | Product display name |
| `category` | One of: `business`, `portfolio`, `agency`, `restaurant`, `ecommerce`, `saas`, `personal`, `realestate`, `education`, `fitness` |
| `tier` | Label: `Standard Website`, `Premium Website`, or `Advanced Website` |
| `price` | Numeric price in USD |
| `isNew` | Shows "New" badge |
| `isFeatured` | Shows "Featured" badge and sort priority |
| `addedDate` | ISO date string for "Newest" sort |
| `shortDesc` | Short card description |
| `fullDesc` | Full modal description |
| `pages` | Array of page descriptions |
| `features` | Array of included features |
| `tech` | Array of technology labels |
| `sourceCode` | Boolean — is source code included? |
| `demoUrl` | URL to live demo |
| `demoIsLive` | Boolean — is the demo deployed? |
| `packageType` | `Frontend Template`, `Full-stack`, etc. |
| `installRequirements` | What is needed to run the website |
| `customisationOptions` | What can be changed as a paid add-on |
| `licence` | `standard` or `commercial` |
| `knownLimitations` | Array of clearly stated limitations |

---

## Before Going Live — Required Configuration

### 1. Payment System
The purchase buttons show a notice because no payment provider is configured. Before accepting payments:

- Choose a payment provider: [Stripe](https://stripe.com), [Paddle](https://paddle.com), [Lemon Squeezy](https://lemonsqueezy.com), etc.
- Set up server-side checkout session creation (never process payments client-side only)
- Implement secure file delivery after confirmed payment
- Update the `handlePurchase()` function in `js/store.js`

### 2. Contact Form
The form has no backend. To enable email delivery:

- **Formspree**: Set `action` attribute and method to `POST` on the form element
- **EmailJS**: Add their SDK and configure template IDs
- **Netlify Forms**: Add `data-netlify="true"` if deployed on Netlify
- Update `js/form.js` to replace the `showConfigNotice()` call with real submission logic

### 3. Live Product Demos
Demo URLs are currently placeholders. For each product in `js/data.js`:
- Deploy the actual demo website
- Update `demoUrl` to the live URL
- Set `demoIsLive: true`

### 4. Product Thumbnail Images
Cards currently use CSS-generated mock designs. To use real images:
- Add screenshots to an `img/products/` directory
- Update `buildThumbMock()` in `js/store.js` to use `<img>` elements

### 5. Legal Documents
The pages in `pages/legal.html` are placeholder templates:
- Have all documents reviewed by a qualified legal professional
- Update governing law clauses to your jurisdiction
- Ensure the Privacy Policy reflects actual data practices
- Add cookie consent if required by applicable law

---

## Design System

| Token | Value |
|---|---|
| Background | `#0a0a0a` |
| Surface | `#111111` |
| Foreground | `#f0f0ec` |
| Accent | `#c3ff00` (Electric Chartreuse) |
| Font — Sans | Inter |
| Font — Display | Space Grotesk |

Edit `css/tokens.css` to update the design system globally.

---

## Business Model Clarity

> "Ready-made websites are sold at their listed prices. Features outside the advertised package are available at an additional cost, subject to approval and a separate quotation."

- Every product has a fixed scope defined on its product page
- No feature is implied beyond what is explicitly listed
- A database, admin dashboard, authentication, payment gateway, hosting, or domain is **not** automatically included
- The same template may be sold to multiple customers unless an exclusive licence is negotiated separately

---

*This project was built for BUYWEB, founded by Mohamed Shaheem.*
