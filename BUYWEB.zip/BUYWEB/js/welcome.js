/**
 * BUYWEB — Cinematic Welcome Screen Controller
 *
 * Orchestrates a ~2.7s premium brand introduction sequence:
 *   Phase 1 (0–400ms)     — Dark opening, central chartreuse glow
 *   Phase 2 (400–1200ms)  — Logo SVG line-draw + wordmark reveal
 *   Phase 3 (1000–1800ms) — Tagline + brand statement fade in
 *   Phase 4 (1800–2700ms) — Cinematic mask-wipe exit into homepage
 *   Phase 5              — Overlay removed, homepage interactive
 *
 * Respects:
 *   - sessionStorage to skip on repeat visits within a session
 *   - prefers-reduced-motion (handled in CSS, compressed timing here)
 *   - Graceful fallback if sessionStorage is unavailable
 *   - Real app readiness: waits for DOMContentLoaded at minimum
 */

(function () {
  'use strict';

  /* ── Constants ──────────────────────────────── */
  var SESSION_KEY = 'buyweb_welcomed';

  /* ── Timing (ms) ────────────────────────────── */
  var T_PHASE1 = 0;        // Glow
  var T_PHASE2 = 400;      // Logo + wordmark
  var T_PHASE3 = 1000;     // Tagline
  var T_PHASE4 = 1800;     // Exit transition
  var T_CLEANUP = 2700;    // Remove overlay entirely

  /* ── Session check ─────────────────────────── */
  function hasSeenWelcome() {
    try {
      return sessionStorage.getItem(SESSION_KEY) === '1';
    } catch (e) {
      return false;
    }
  }

  function markWelcomeSeen() {
    try {
      sessionStorage.setItem(SESSION_KEY, '1');
    } catch (e) {
      // Storage unavailable — silently continue
    }
  }

  /* ── Reduced motion check ──────────────────── */
  function prefersReducedMotion() {
    return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }

  /* ── Main ───────────────────────────────────── */
  var overlay = document.getElementById('bw-welcome');
  if (!overlay) return; // No overlay in DOM — bail

  // Skip if already seen this session
  if (hasSeenWelcome()) {
    overlay.classList.add('phase-done');
    return;
  }

  // Lock scroll
  document.body.classList.add('bw-welcome-active');

  // Show loading bar in case app takes time
  var loadbar = overlay.querySelector('.bw-welcome__loadbar');
  var appReady = false;
  var animReady = false;

  // Mark app as ready when DOM is settled
  function onAppReady() {
    appReady = true;
    if (loadbar) loadbar.classList.remove('visible');
    if (animReady) finish();
  }

  // If the document is already loaded, app is ready
  if (document.readyState === 'complete') {
    appReady = true;
  } else {
    // Show loadbar after a short delay to avoid flash on fast loads
    setTimeout(function () {
      if (!appReady && loadbar) loadbar.classList.add('visible');
    }, 600);
    window.addEventListener('load', onAppReady);
  }

  /* ── Reduced motion → compressed sequence ──── */
  if (prefersReducedMotion()) {
    T_PHASE1 = 0;
    T_PHASE2 = 50;
    T_PHASE3 = 150;
    T_PHASE4 = 400;
    T_CLEANUP = 800;
  }

  /* ── Run animation phases ──────────────────── */
  setTimeout(function () {
    overlay.classList.add('phase-1');
  }, T_PHASE1);

  setTimeout(function () {
    overlay.classList.add('phase-2');
  }, T_PHASE2);

  setTimeout(function () {
    overlay.classList.add('phase-3');
  }, T_PHASE3);

  setTimeout(function () {
    overlay.classList.add('phase-4');
    animReady = true;
    if (appReady) finish();
  }, T_PHASE4);

  /* ── Finish: cleanup overlay ───────────────── */
  var finished = false;
  function finish() {
    if (finished) return;
    finished = true;
    setTimeout(function () {
      overlay.classList.add('phase-done');
      document.body.classList.remove('bw-welcome-active');
      markWelcomeSeen();
      // Ensure no invisible blockers remain
      overlay.setAttribute('aria-hidden', 'true');
      overlay.style.pointerEvents = 'none';
    }, T_CLEANUP - T_PHASE4);
  }

  /* ── Safety net: never block longer than 6s ── */
  setTimeout(function () {
    if (!overlay.classList.contains('phase-done')) {
      overlay.classList.add('phase-done');
      document.body.classList.remove('bw-welcome-active');
      markWelcomeSeen();
    }
  }, 6000);

})();
