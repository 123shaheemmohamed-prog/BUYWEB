/**
 * BUYWEB — Supabase Client Integration Module
 * ============================================
 * Official Supabase JS client integration for persistent PostgreSQL database,
 * Supabase Auth, Row Level Security, private Storage, and Edge Functions.
 */

(function () {
  'use strict';

  const config = window.BUYWEB_CONFIG;
  let client = null;

  // Initialize client if credentials exist and library is loaded
  if (config && config.isConfigured() && window.supabase && typeof window.supabase.createClient === 'function') {
    client = window.supabase.createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
      },
    });
  } else {
    console.info(
      'BUYWEB Backend: Supabase project credentials not yet configured in js/supabase-config.js. Store is currently operating in preview fallback mode. See DEPLOYMENT.md for setup instructions.'
    );
  }

  // Helper to get active user JWT for Edge Function calls
  async function getAuthHeader() {
    if (!client) return {};
    const { data: { session } } = await client.auth.getSession();
    if (session?.access_token) {
      return { Authorization: `Bearer ${session.access_token}` };
    }
    return {};
  }

  const BUYWEB_SUPABASE = {
    get client() {
      return client;
    },

    isConfigured() {
      return Boolean(client && config.isConfigured());
    },

    // ──────────────── AUTHENTICATION ────────────────
    auth: {
      async signUp(email, password, fullName) {
        if (!client) throw new Error('Supabase is not configured.');
        const { data, error } = await client.auth.signUp({
          email,
          password,
          options: {
            data: { full_name: fullName },
            emailRedirectTo: `${window.location.origin}/`,
          },
        });
        if (error) throw error;
        return data;
      },

      async signIn(email, password) {
        if (!client) throw new Error('Supabase is not configured.');
        const { data, error } = await client.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        return data;
      },

      async signOut() {
        if (!client) return;
        const { error } = await client.auth.signOut();
        if (error) throw error;
      },

      async resetPassword(email) {
        if (!client) throw new Error('Supabase is not configured.');
        const { data, error } = await client.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/#reset-password`,
        });
        if (error) throw error;
        return data;
      },

      async getSession() {
        if (!client) return null;
        const { data: { session } } = await client.auth.getSession();
        return session;
      },

      async getUser() {
        if (!client) return null;
        const { data: { user } } = await client.auth.getUser();
        return user;
      },

      async getProfile(userId) {
        if (!client || !userId) return null;
        const { data, error } = await client
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .maybeSingle();

        if (error) {
          console.warn('Could not fetch user profile:', error.message);
          return null;
        }

        if (!data) {
          try {
            const { data: { user } } = await client.auth.getUser();
            if (user && user.id === userId) {
              const newProfile = {
                id: userId,
                email: user.email || '',
                full_name: user.user_metadata?.full_name || '',
                role: 'customer'
              };
              const { data: created } = await client
                .from('profiles')
                .upsert(newProfile, { onConflict: 'id' })
                .select('*')
                .maybeSingle();
              if (created) return created;
            }
          } catch (_e) {
            // Handled gracefully
          }
        }
        return data || null;
      },

      async updateProfile(updates) {
        if (!client) throw new Error('Supabase is not configured.');
        const user = await this.getUser();
        if (!user) throw new Error('Not authenticated.');
        const { data, error } = await client
          .from('profiles')
          .update(updates)
          .eq('id', user.id)
          .select()
          .maybeSingle();
        if (error) throw error;
        return data;
      },

      onAuthStateChange(callback) {
        if (!client) return { data: { subscription: { unsubscribe: () => {} } } };
        return client.auth.onAuthStateChange(callback);
      },
    },

    // ──────────────── PRODUCTS ────────────────
    products: {
      async getPublishedProducts() {
        if (!client) return null;
        let { data, error } = await client
          .from('public_products')
          .select('*')
          .order('featured', { ascending: false });

        if (error || !data) {
          const res = await client
            .from('products')
            .select(`
              id, name, slug, short_description, full_description, category,
              product_type, price, currency, package_tier, thumbnail_url,
              gallery_images, demo_url, technology_stack, included_pages,
              included_features, source_code_included, responsive_design,
              installation_instructions, licence_type, licence_terms,
              known_limitations, publication_status, featured, created_at
            `)
            .eq('publication_status', 'published')
            .order('featured', { ascending: false });
          data = res.data;
          error = res.error;
        }

        if (error) {
          console.warn('Could not fetch products from database:', error.message);
          return null;
        }
        return data;
      },

      async getProduct(idOrSlug) {
        if (!client) return null;
        const { data, error } = await client
          .from('products')
          .select('*')
          .or(`id.eq.${idOrSlug},slug.eq.${idOrSlug}`)
          .single();
        if (error) return null;
        return data;
      },
    },

    // ──────────────── ORDERS & CHECKOUT ────────────────
    orders: {
      async createOrder(productId, licenceType = 'standard', customerEmail = '', customerName = '') {
        if (!config.isConfigured()) {
          throw new Error('Supabase backend is not configured.');
        }

        // 1. Try Edge function
        try {
          const authHeader = await getAuthHeader();
          const response = await fetch(`${config.FUNCTIONS_URL}/create-order`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...authHeader,
            },
            body: JSON.stringify({
              productId,
              licenceType,
              customerEmail,
              customerName,
            }),
          });

          if (response.ok) {
            return await response.json();
          }
        } catch (_edgeErr) {
          // Fall back to database RPC if available
        }

        // 2. Try database RPC function if created
        if (client) {
          try {
            const { data, error } = await client.rpc('create_customer_order', {
              p_product_id: productId,
              p_licence_type: licenceType
            });
            if (!error && data) {
              return data;
            }
          } catch (_rpcErr) {
            // Handled
          }
        }

        throw new Error('Order creation service is connecting. Please ensure backend database functions are active.');
      },

      async verifyPayment(orderId, razorpayOrderId, razorpayPaymentId, razorpaySignature) {
        const authHeader = await getAuthHeader();
        const response = await fetch(`${config.FUNCTIONS_URL}/verify-payment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeader,
          },
          body: JSON.stringify({
            orderId,
            razorpayOrderId,
            razorpayPaymentId,
            razorpaySignature,
          }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || 'Payment verification failed.');
        }
        return result;
      },

      async getMyOrders() {
        if (!client) return [];
        const { data, error } = await client
          .from('orders')
          .select(`
            *,
            order_items (
              id,
              product_name_snapshot,
              licence_snapshot,
              unit_price,
              quantity,
              line_total
            )
          `)
          .order('created_at', { ascending: false });

        if (error) {
          console.warn('Could not fetch user orders:', error.message);
          return [];
        }
        return data || [];
      },
    },

    // ──────────────── LICENCES ────────────────
    licences: {
      async getMyLicences() {
        if (!client) return [];
        const { data, error } = await client
          .from('licences')
          .select(`
            *,
            order_items (
              product_name_snapshot,
              order_id
            )
          `)
          .order('issued_at', { ascending: false });

        if (error) {
          console.warn('Could not fetch user licences:', error.message);
          return [];
        }
        return data || [];
      },
    },

    // ──────────────── DOWNLOADS ────────────────
    downloads: {
      async requestDownloadLink(orderItemId) {
        if (!config.isConfigured()) {
          throw new Error('Supabase backend is not configured.');
        }

        const authHeader = await getAuthHeader();
        const response = await fetch(`${config.FUNCTIONS_URL}/create-download-link`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeader,
          },
          body: JSON.stringify({ orderItemId }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || 'Failed to generate download link.');
        }
        return result;
      },
    },

    // ──────────────── CUSTOMIZATION REQUESTS ────────────────
    customization: {
      async submitRequest(formData) {
        if (!config.isConfigured()) {
          throw new Error('Supabase backend is not configured.');
        }

        // 1. Try Edge function first if deployed
        try {
          const authHeader = await getAuthHeader();
          const response = await fetch(`${config.FUNCTIONS_URL}/submit-customization-request`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...authHeader,
            },
            body: JSON.stringify(formData),
          });

          if (response.ok) {
            const result = await response.json();
            return result;
          }
        } catch (_edgeErr) {
          // Fall back to direct database insert via RLS
        }

        // 2. Direct database insert using Row Level Security policy "customization_insert_public"
        if (client) {
          const user = (await client.auth.getUser())?.data?.user;
          const { data, error } = await client
            .from('customization_requests')
            .insert({
              customer_id: user ? user.id : null,
              customer_name: formData.name,
              customer_email: formData.email,
              requested_features: formData.feature,
              detailed_requirements: formData.requirements,
              budget_range: formData.budget || null,
              preferred_completion_date: formData.preferredDate || null,
              status: 'new',
            })
            .select('id, request_reference')
            .maybeSingle();

          if (error) {
            throw new Error(error.message || 'Failed to submit customization enquiry.');
          }

          return {
            success: true,
            reference: data?.request_reference || data?.id || 'SUBMITTED',
            message: 'Enquiry received successfully.',
          };
        }

        throw new Error('Failed to submit customization enquiry.');
      },

      async getMyRequests() {
        if (!client) return [];
        const { data, error } = await client
          .from('customization_requests')
          .select('*')
          .order('created_at', { ascending: false });

        if (error) {
          console.warn('Could not fetch customization requests:', error.message);
          return [];
        }
        return data || [];
      },
    },

    // ──────────────── ADMINISTRATOR OPERATIONS ────────────────
    admin: {
      async getAnalytics() {
        const authHeader = await getAuthHeader();
        const response = await fetch(`${config.FUNCTIONS_URL}/admin-actions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeader,
          },
          body: JSON.stringify({ action: 'get-analytics' }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || 'Failed to load analytics.');
        }
        return result.analytics;
      },

      async getAllOrders() {
        if (!client) return [];
        const { data, error } = await client
          .from('orders')
          .select('*, order_items(*)')
          .order('created_at', { ascending: false });
        if (error) throw error;
        return data || [];
      },

      async processRefund(orderId, reason = '') {
        const authHeader = await getAuthHeader();
        const response = await fetch(`${config.FUNCTIONS_URL}/process-refund`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeader,
          },
          body: JSON.stringify({ orderId, reason }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || 'Failed to process refund.');
        }
        return result;
      },

      async getAllEnquiries() {
        if (!client) return [];
        const { data, error } = await client
          .from('customization_requests')
          .select('*')
          .order('created_at', { ascending: false });
        if (error) throw error;
        return data || [];
      },

      async quoteEnquiry(requestId, quotedAmount, adminNotes, status = 'quoted') {
        const authHeader = await getAuthHeader();
        const response = await fetch(`${config.FUNCTIONS_URL}/admin-actions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...authHeader,
          },
          body: JSON.stringify({
            action: 'quote-customization',
            requestId,
            quotedAmount,
            adminNotes,
            status,
          }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || 'Failed to update quote.');
        }
        return result;
      },
    },
  };

  window.BUYWEB_SUPABASE = BUYWEB_SUPABASE;
})();
