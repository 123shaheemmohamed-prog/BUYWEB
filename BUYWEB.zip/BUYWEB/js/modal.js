/**
 * BUYWEB — Product Detail Modal
 * Renders full product details in the modal overlay.
 */

(function () {
  'use strict';

  const overlay   = document.getElementById('modal-overlay');
  const closeBtn  = document.getElementById('modal-close');
  const content   = document.getElementById('modal-content');

  let lastFocused = null;

  /* ── Build licence permissions ──────────────────── */
  function buildLicencePermissions(permissions) {
    return permissions.map(p => `
      <div class="lp-item ${p.status}">
        <strong>${p.status === 'allowed' ? '✓' : p.status === 'not-allowed' ? '✗' : '~'}</strong>
        ${p.label}
      </div>`).join('');
  }

  /* ── Build modal HTML ───────────────────────────── */
  function buildModalContent(product) {
    const licence = LICENCES[product.licence] || LICENCES.standard;
    const priceDisplay = `$${product.price}`;
    const sourceLabel = product.sourceCode ? '✓ Included' : '✗ Not included in this package';

    return `
      <div class="modal-hero">
        <div class="modal-thumb" aria-label="${product.name} website preview">
          <div class="thumb-mock">
            <div class="mock-topbar">
              <span class="mock-dot" style="background:#ff5f57"></span>
              <span class="mock-dot" style="background:#febc2e"></span>
              <span class="mock-dot" style="background:#28c840"></span>
              <span class="mock-urlbar"></span>
            </div>
            <div class="mock-body">
              <div class="mock-hero" data-cat="${product.category}" style="height:55%">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="rgba(195,255,0,0.5)" stroke-width="1.5" aria-hidden="true">
                  <rect x="3" y="3" width="18" height="18" rx="2"/>
                  <circle cx="12" cy="9" r="3"/>
                  <path d="M6 21v-1a6 6 0 0 1 12 0v1"/>
                </svg>
              </div>
              <div class="mock-headline"></div>
              <div class="mock-sub"></div>
              <div class="mock-cards-row">
                <div class="mock-small-card"></div>
                <div class="mock-small-card"></div>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-meta">
          <p class="modal-category">${product.categoryLabel}</p>
          <h2 class="modal-title" id="modal-title">${product.name}</h2>
          <div class="modal-price-row">
            <span class="modal-price">${priceDisplay}</span>
            <span class="modal-price-tier">${product.tier}</span>
          </div>
          <p class="modal-desc">${product.fullDesc}</p>
          <div class="modal-actions">
            <a
              href="${product.demoUrl}"
              class="btn btn-ghost"
              ${product.demoIsLive ? 'target="_blank" rel="noopener noreferrer"' : 'onclick="return false" title="Demo coming soon"'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <rect x="2" y="3" width="20" height="14" rx="2"/>
                <line x1="8" y1="21" x2="16" y2="21"/>
                <line x1="12" y1="17" x2="12" y2="21"/>
              </svg>
              ${product.demoIsLive ? 'Open Live Demo' : 'Demo Coming Soon'}
            </a>
            <button class="btn btn-primary" id="modal-purchase-btn" data-product-id="${product.id}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                <line x1="1" y1="10" x2="23" y2="10"/>
              </svg>
              Purchase — ${priceDisplay}
            </button>
          </div>
        </div>
      </div>

      <div class="modal-detail-grid">
        <div class="modal-detail-section">
          <h3>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <rect x="2" y="3" width="20" height="14" rx="2"/>
              <line x1="8" y1="21" x2="16" y2="21"/>
              <line x1="12" y1="17" x2="12" y2="21"/>
            </svg>
            Included Pages
          </h3>
          <ul class="modal-list">
            ${product.pages.map(p => `<li>${p}</li>`).join('')}
          </ul>
        </div>

        <div class="modal-detail-section">
          <h3>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <polyline points="20 6 9 17 4 12"/>
            </svg>
            Included Features
          </h3>
          <ul class="modal-list">
            ${product.features.map(f => `<li>${f}</li>`).join('')}
          </ul>
        </div>

        <div class="modal-detail-section">
          <h3>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <polyline points="16 18 22 12 16 6"/>
              <polyline points="8 6 2 12 8 18"/>
            </svg>
            Technology Stack
          </h3>
          <div class="modal-tech-pills">
            ${product.tech.map(t => `<span class="tech-pill">${t}</span>`).join('')}
          </div>
          <ul class="modal-list" style="margin-top: var(--space-3);">
            <li>Package type: <strong style="color:var(--fg); margin-left:4px">${product.packageType}</strong></li>
            <li>Source code: <strong style="color:var(--fg); margin-left:4px">${sourceLabel}</strong></li>
            <li>Responsive: <strong style="color:var(--accent); margin-left:4px">✓ Yes</strong></li>
          </ul>
        </div>

        <div class="modal-detail-section">
          <h3>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            Installation Requirements
          </h3>
          <p style="font-size:var(--text-sm);color:var(--fg-muted);line-height:var(--leading-base)">${product.installRequirements}</p>
          <h3 style="margin-top:var(--space-4)">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
            Customisation Options
          </h3>
          <p style="font-size:var(--text-sm);color:var(--fg-muted);line-height:var(--leading-base)">${product.customisationOptions} — available as a paid add-on.</p>
        </div>
      </div>

      <div class="modal-licence-box">
        <h3>${licence.label}</h3>
        <p>${licence.description}</p>
        <div class="licence-permissions">
          ${buildLicencePermissions(licence.permissions)}
        </div>
        <p style="font-size:var(--text-xs);color:var(--fg-subtle);font-style:italic;margin-top:var(--space-2)">
          The same template may be sold to multiple customers unless an exclusive licence has been purchased separately. Licence terms should be reviewed before purchase. The final applicable terms are those in the <a href="pages/legal.html#licence" style="color:var(--accent);text-decoration:underline">Licence Information</a> page.
        </p>
      </div>

      ${product.knownLimitations && product.knownLimitations.length > 0 ? `
      <div class="modal-limitations">
        <h3>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
            <line x1="12" y1="9" x2="12" y2="13"/>
            <line x1="12" y1="17" x2="12.01" y2="17"/>
          </svg>
          Known Limitations
        </h3>
        <ul>
          ${product.knownLimitations.map(l => `<li>${l}</li>`).join('')}
        </ul>
      </div>` : ''}`;
  }

  /* ── Open modal ─────────────────────────────────── */
  function openModal(product) {
    lastFocused = document.activeElement;
    content.innerHTML = buildModalContent(product);
    overlay.hidden = false;
    document.body.style.overflow = 'hidden';

    // Scroll modal to top
    overlay.scrollTop = 0;

    // Focus first interactive element
    const firstFocusable = overlay.querySelector('button, a, [tabindex]');
    if (firstFocusable) firstFocusable.focus();

    // Bind purchase button inside modal
    const purchaseBtn = document.getElementById('modal-purchase-btn');
    if (purchaseBtn) {
      purchaseBtn.addEventListener('click', () => {
        closeModal();
        // Trigger purchase from store.js context
        const btn = document.querySelector(`[data-product-id="${product.id}"].btn-purchase`);
        if (btn) btn.click();
      });
    }
  }

  /* ── Close modal ────────────────────────────────── */
  function closeModal() {
    overlay.hidden = true;
    document.body.style.overflow = '';
    if (lastFocused) lastFocused.focus();
  }

  /* ── Expose openModal ────────────────────────────── */
  window.openModal = openModal;

  /* ── Event listeners ────────────────────────────── */
  closeBtn.addEventListener('click', closeModal);

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !overlay.hidden) closeModal();
  });

  // Focus trap
  overlay.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    const focusables = overlay.querySelectorAll(
      'a[href], button:not([disabled]), input, textarea, select, [tabindex]:not([tabindex="-1"])'
    );
    const first = focusables[0];
    const last  = focusables[focusables.length - 1];
    if (e.shiftKey) {
      if (document.activeElement === first) { e.preventDefault(); last.focus(); }
    } else {
      if (document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

})();
