/**
 * BUYWEB — Main Initialisation
 * Shared utilities, footer year, scroll animations.
 */

(function () {
  'use strict';

  /* ── Footer year ────────────────────────────────── */
  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ── Scroll-reveal animations ───────────────────── */
  if ('IntersectionObserver' in window) {
    const revealEls = document.querySelectorAll(
      '.step-item, .wyg-card, .upgrade-item, .pricing-card, .product-card'
    );

    // Add initial state
    revealEls.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -40px 0px',
    });

    revealEls.forEach(el => observer.observe(el));
  }

  /* ── Smooth scroll for anchor links ─────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href').slice(1);
      const target   = document.getElementById(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  /* ── Skip link ──────────────────────────────────── */
  const skipLink = document.createElement('a');
  skipLink.href = '#main-content';
  skipLink.textContent = 'Skip to main content';
  skipLink.className = 'skip-link';
  skipLink.style.cssText = `
    position: fixed;
    top: -100%;
    left: 0;
    z-index: 9999;
    background: var(--accent);
    color: var(--fg-invert);
    padding: 0.75em 1.5em;
    font-weight: 700;
    font-size: 0.875rem;
    text-decoration: none;
    transition: top 0.2s ease;
    border-radius: 0 0 var(--radius) 0;
  `;
  skipLink.addEventListener('focus', () => skipLink.style.top = '0');
  skipLink.addEventListener('blur',  () => skipLink.style.top = '-100%');
  document.body.insertBefore(skipLink, document.body.firstChild);

})();
