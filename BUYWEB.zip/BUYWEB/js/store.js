/**
 * BUYWEB — Store Engine
 * Renders product cards, handles search, filtering, and sorting.
 */

(function () {
  'use strict';

  const grid       = document.getElementById('products-grid');
  const emptyState = document.getElementById('store-empty');
  const searchInput = document.getElementById('store-search');
  const sortSelect  = document.getElementById('sort-select');
  const filterChips = document.querySelectorAll('.filter-chip');

  let activeCategory = 'all';
  let activeSort     = 'featured';
  let searchQuery    = '';

  /* ── Build thumbnail mock ──────────────────────── */
  function buildThumbMock(cat) {
    return `
      <div class="thumb-mock">
        <div class="mock-topbar">
          <span class="mock-dot" style="background:#ff5f57"></span>
          <span class="mock-dot" style="background:#febc2e"></span>
          <span class="mock-dot" style="background:#28c840"></span>
          <span class="mock-urlbar"></span>
        </div>
        <div class="mock-body">
          <div class="mock-hero" data-cat="${cat}">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="rgba(195,255,0,0.4)" stroke-width="1.5" aria-hidden="true">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="12" cy="9" r="3"/>
              <path d="M6 21v-1a6 6 0 0 1 12 0v1"/>
            </svg>
          </div>
          <div class="mock-headline"></div>
          <div class="mock-sub"></div>
          <div class="mock-cards-row">
            <div class="mock-small-card"></div>
            <div class="mock-small-card"></div>
            <div class="mock-small-card"></div>
          </div>
        </div>
      </div>`;
  }

  /* ── Build badges ──────────────────────────────── */
  function buildBadges(product) {
    let html = '';
    if (product.isFeatured) {
      html += `<span class="badge badge-featured">Featured</span>`;
    }
    if (product.isNew) {
      html += `<span class="badge badge-new">New</span>`;
    }
    return html ? `<div class="card-badges">${html}</div>` : '';
  }

  /* ── Build tech pills ──────────────────────────── */
  function buildTechPills(tech) {
    return tech.map(t => `<span class="tech-pill">${t}</span>`).join('');
  }

  /* ── Build single product card ─────────────────── */
  function buildCard(product) {
    const priceDisplay = `$${product.price}`;

    return `
      <article class="product-card" role="listitem" data-id="${product.id}" data-cat="${product.category}">
        ${buildBadges(product)}
        <div class="card-thumb" aria-label="${product.name} website preview">
          <div class="card-thumb-inner">
            ${buildThumbMock(product.category)}
          </div>
          <div class="card-thumb-overlay">
            <a
              href="${product.demoUrl}"
              class="demo-link-btn"
              aria-label="View live demo of ${product.name}"
              ${product.demoIsLive ? '' : 'onclick="return false" title="Demo coming soon"'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                <polyline points="15 3 21 3 21 9"/>
                <line x1="10" y1="14" x2="21" y2="3"/>
              </svg>
              ${product.demoIsLive ? 'Open Live Demo' : 'Demo Coming Soon'}
            </a>
          </div>
        </div>

        <div class="card-body">
          <div class="card-meta">
            <span class="card-category">${product.categoryLabel}</span>
            <span class="card-price-badge">${priceDisplay}</span>
          </div>
          <h3 class="card-title">${product.name}</h3>
          <p class="card-desc">${product.shortDesc}</p>
          <div class="card-tech">${buildTechPills(product.tech)}</div>
        </div>

        <div class="card-actions">
          <button
            class="btn-details"
            aria-label="View details for ${product.name}"
            data-product-id="${product.id}"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            View Details
          </button>
          <a
            href="${product.demoUrl}"
            class="btn-demo"
            aria-label="Live demo of ${product.name}"
            ${product.demoIsLive ? '' : 'onclick="return false" title="Demo coming soon"'}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
              <rect x="2" y="3" width="20" height="14" rx="2"/>
              <line x1="8" y1="21" x2="16" y2="21"/>
              <line x1="12" y1="17" x2="12" y2="21"/>
            </svg>
            ${product.demoIsLive ? 'Live Demo' : 'Demo Soon'}
          </a>
          <button
            class="btn-purchase"
            aria-label="Purchase ${product.name} for ${priceDisplay}"
            data-product-id="${product.id}"
          >
            Purchase — ${priceDisplay}
          </button>
        </div>
      </article>`;
  }

  /* ── Filter / sort / search products ───────────── */
  function getFilteredProducts() {
    let list = [...PRODUCTS];

    // Category filter
    if (activeCategory !== 'all') {
      list = list.filter(p => p.category === activeCategory);
    }

    // Search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.shortDesc.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q) ||
        p.tech.some(t => t.toLowerCase().includes(q))
      );
    }

    // Sort
    switch (activeSort) {
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        list.sort((a, b) => new Date(b.addedDate) - new Date(a.addedDate));
        break;
      case 'featured':
      default:
        list.sort((a, b) => {
          if (a.isFeatured && !b.isFeatured) return -1;
          if (!a.isFeatured && b.isFeatured) return 1;
          if (a.isNew && !b.isNew) return -1;
          if (!a.isNew && b.isNew) return 1;
          return 0;
        });
        break;
    }

    return list;
  }

  /* ── Render ────────────────────────────────────── */
  function render() {
    const products = getFilteredProducts();

    if (products.length === 0) {
      grid.innerHTML = '';
      emptyState.classList.remove('hidden');
    } else {
      emptyState.classList.add('hidden');
      grid.innerHTML = products.map(buildCard).join('');
      attachCardListeners();
    }
  }

  /* ── Attach card button listeners ──────────────── */
  function attachCardListeners() {
    // View Details buttons
    grid.querySelectorAll('.btn-details').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.productId;
        const product = PRODUCTS.find(p => p.id === id);
        if (product && typeof window.openModal === 'function') window.openModal(product);
      });
    });

    // Purchase buttons
    grid.querySelectorAll('.btn-purchase').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.productId;
        handlePurchase(id);
      });
    });
  }

  /* ── Purchase handler ──────────────────────────── */
  async function handlePurchase(productId) {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product) return;

    const sb = window.BUYWEB_SUPABASE;

    // If Supabase is connected, execute secure backend checkout workflow
    if (sb && sb.isConfigured()) {
      try {
        const user = await sb.auth.getUser();
        if (!user) {
          if (window.FORM && typeof window.FORM.showToast === 'function') {
            window.FORM.showToast('Please sign in or create an account to purchase and receive your licence.', 5000);
          }
          if (window.BUYWEB_AUTH_UI && typeof window.BUYWEB_AUTH_UI.openAuthModal === 'function') {
            window.BUYWEB_AUTH_UI.openAuthModal();
          }
          return;
        }

        // 1. Create order on trusted server
        const orderRes = await sb.orders.createOrder(product.id, 'standard');

        // 2. If Razorpay is configured with credentials and script loaded
        if (orderRes.razorpayKeyId && orderRes.razorpayOrderId && window.Razorpay) {
          const rzpOptions = {
            key: orderRes.razorpayKeyId,
            amount: orderRes.amount,
            currency: orderRes.currency,
            name: 'BUYWEB',
            description: `${product.name} Website Template`,
            order_id: orderRes.razorpayOrderId,
            handler: async function (rzpResp) {
              try {
                await sb.orders.verifyPayment(
                  orderRes.orderId,
                  rzpResp.razorpay_order_id,
                  rzpResp.razorpay_payment_id,
                  rzpResp.razorpay_signature
                );
                if (window.FORM) window.FORM.showToast('Payment verified! Licence and source files now available.', 6000);
                if (window.BUYWEB_AUTH_UI) window.BUYWEB_AUTH_UI.openAccountModal();
              } catch (vErr) {
                alert(`Payment verification failed: ${vErr.message}`);
              }
            },
            prefill: {
              name: user.user_metadata?.full_name || '',
              email: user.email,
            },
            theme: { color: '#c3ff00' },
          };

          const rzpInstance = new window.Razorpay(rzpOptions);
          rzpInstance.open();
          return;
        }

        // 3. If Gateway credentials are not yet added in Supabase secrets
        showServerOrderSuccess(product, orderRes);
        return;
      } catch (orderErr) {
        alert(orderErr.message || 'Failed to initialize order.');
        return;
      }
    }

    // Fallback notice if Supabase credentials have not yet been plugged in
    showPaymentNotice(product);
  }

  function showServerOrderSuccess(product, orderRes) {
    const modal = document.getElementById('modal-overlay');
    const content = document.getElementById('modal-content');
    const totalFormatted = (orderRes.amount / 100).toLocaleString('en-IN', { style: 'currency', currency: orderRes.currency });

    content.innerHTML = `
      <div style="padding: var(--space-4) 0; display: flex; flex-direction: column; gap: var(--space-6); max-width: 540px; margin: 0 auto; text-align: center;">
        <div style="width: 60px; height: 60px; background: rgba(34, 197, 94, 0.1); border: 1.5px solid #22c55e; border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; margin: 0 auto; color: #22c55e;">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        <div>
          <h2 style="font-size: var(--text-2xl); font-weight: 800; margin-bottom: var(--space-2);">Order Created in Database</h2>
          <p style="font-size: var(--text-sm); color: var(--fg-muted);">Order Number: <strong style="color: var(--fg);">${orderRes.orderNumber}</strong></p>
        </div>

        <div class="bw-checkout-box" style="text-align: left;">
          <div class="bw-checkout-row">
            <span>Template</span>
            <strong style="color: var(--fg);">${product.name}</strong>
          </div>
          <div class="bw-checkout-row">
            <span>Licence</span>
            <span>Standard (1 Project)</span>
          </div>
          <div class="bw-checkout-row">
            <span>Server Price</span>
            <span>${totalFormatted}</span>
          </div>
          <div class="bw-checkout-row total">
            <span>Total Calculated</span>
            <span>${totalFormatted}</span>
          </div>
        </div>

        <div style="background: rgba(234, 179, 8, 0.08); border: 1.5px solid rgba(234, 179, 8, 0.25); border-radius: var(--radius-md); padding: var(--space-4); text-align: left;">
          <p style="font-size: var(--text-sm); font-weight: 700; color: #eab308; margin-bottom: var(--space-1);">Payment Gateway Pending Activation</p>
          <p style="font-size: var(--text-xs); color: var(--fg-muted); line-height: var(--leading-base);">
            This pending order was created directly in PostgreSQL using your Supabase backend. To accept real credit/debit card, UPI, or netbanking payments, configure your payment gateway API credentials in Supabase Edge Function secrets.
          </p>
        </div>

        <button class="btn btn-primary" onclick="document.getElementById('modal-overlay').hidden=true; document.body.style.overflow=''">Done</button>
      </div>`;

    modal.hidden = false;
    document.body.style.overflow = 'hidden';
  }

  function showPaymentNotice(product) {
    const modal = document.getElementById('modal-overlay');
    const content = document.getElementById('modal-content');

    content.innerHTML = `
      <div style="padding: var(--space-4) 0; display: flex; flex-direction: column; gap: var(--space-6); max-width: 520px; margin: 0 auto; text-align: center;">
        <div style="width: 60px; height: 60px; background: var(--accent-muted); border: 1.5px solid var(--border-accent); border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; margin: 0 auto; color: var(--accent);">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
            <line x1="1" y1="10" x2="23" y2="10"/>
          </svg>
        </div>
        <div>
          <h2 style="font-size: var(--text-2xl); font-weight: 800; margin-bottom: var(--space-3);">Purchase: ${product.name}</h2>
          <p style="font-size: var(--text-xl); font-weight: 700; color: var(--accent); margin-bottom: var(--space-4);">$${product.price}</p>
        </div>
        <div style="background: rgba(255,180,0,0.06); border: 1.5px solid rgba(255,180,0,0.2); border-radius: var(--radius-md); padding: var(--space-5); text-align: left;">
          <p style="font-size: var(--text-sm); font-weight: 700; color: #ffb400; margin-bottom: var(--space-2);">⚙ Payment System Not Yet Configured</p>
          <p style="font-size: var(--text-sm); color: var(--fg-muted); line-height: var(--leading-base);">
            The payment and digital delivery system requires configuration before purchases can be processed. This includes setting up a payment provider (such as Stripe or Paddle), a secure checkout flow, and file delivery after confirmed payment.
          </p>
          <p style="font-size: var(--text-sm); color: var(--fg-muted); margin-top: var(--space-3); line-height: var(--leading-base);">
            To enquire about this product, please use the <a href="#contact" onclick="document.getElementById('modal-overlay').hidden=true" style="color: var(--accent); text-decoration: underline;">contact form</a>.
          </p>
        </div>
        <button class="btn btn-ghost" onclick="document.getElementById('modal-overlay').hidden=true; document.body.style.overflow=''">Close</button>
      </div>`;

    modal.hidden = false;
    document.body.style.overflow = 'hidden';
  }

  /* ── Event listeners ───────────────────────────── */
  searchInput.addEventListener('input', () => {
    searchQuery = searchInput.value.trim();
    render();
  });

  sortSelect.addEventListener('change', () => {
    activeSort = sortSelect.value;
    render();
  });

  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      filterChips.forEach(c => {
        c.classList.remove('active');
        c.setAttribute('aria-pressed', 'false');
      });
      chip.classList.add('active');
      chip.setAttribute('aria-pressed', 'true');
      activeCategory = chip.dataset.cat;
      render();
    });
  });

  // Footer nav category links
  document.querySelectorAll('.footer-col a[data-cat]').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const cat = link.dataset.cat;
      // Update filter
      filterChips.forEach(c => {
        const isMatch = c.dataset.cat === cat;
        c.classList.toggle('active', isMatch);
        c.setAttribute('aria-pressed', String(isMatch));
      });
      activeCategory = cat;
      render();
      // Scroll to store
      document.getElementById('store').scrollIntoView({ behavior: 'smooth' });
    });
  });

  /* ── Load products from Supabase database ──────── */
  async function loadProductsFromSupabase() {
    const sb = window.BUYWEB_SUPABASE;
    if (!sb || !sb.isConfigured()) return;

    try {
      const dbProducts = await sb.products.getPublishedProducts();
      if (Array.isArray(dbProducts) && dbProducts.length > 0) {
        const mapped = dbProducts.map(p => {
          const numPrice = Number(p.price);
          const displayPrice = p.currency === 'INR' ? Math.round(numPrice / 8000) : Math.round(numPrice / 100);

          return {
            id: p.slug || p.id,
            dbId: p.id,
            name: p.name,
            category: p.category,
            categoryLabel: p.category ? (p.category.charAt(0).toUpperCase() + p.category.slice(1) + ' Website') : 'Website',
            tier: p.package_tier || 'Standard Website',
            price: displayPrice || 149,
            currency: p.currency || 'INR',
            isNew: false,
            isFeatured: Boolean(p.featured),
            addedDate: p.created_at || '2026-09-01',
            shortDesc: p.short_description || '',
            fullDesc: p.full_description || '',
            pages: Array.isArray(p.included_pages) ? p.included_pages : [],
            features: Array.isArray(p.included_features) ? p.included_features : [],
            tech: Array.isArray(p.technology_stack) ? p.technology_stack : ['HTML5', 'CSS3', 'JavaScript'],
            sourceCode: Boolean(p.source_code_included),
            responsive: Boolean(p.responsive_design),
            demoUrl: p.demo_url || '#',
            demoIsLive: Boolean(p.demo_url && p.demo_url !== '#'),
            packageType: p.product_type || 'Frontend Template',
            installRequirements: p.installation_instructions || 'Static hosting.',
            customisationOptions: 'Colour scheme, logo, text content, page additions.',
            licence: p.licence_type || 'standard',
            knownLimitations: Array.isArray(p.known_limitations)
              ? p.known_limitations
              : (p.known_limitations ? p.known_limitations.split('\n') : [])
          };
        });

        if (typeof PRODUCTS !== 'undefined' && Array.isArray(PRODUCTS)) {
          PRODUCTS.length = 0;
          PRODUCTS.push(...mapped);
          render();
        }
      }
    } catch (err) {
      console.warn('Supabase products sync:', err);
    }
  }

  /* ── Initial render ────────────────────────────── */
  render();
  loadProductsFromSupabase();

})();
