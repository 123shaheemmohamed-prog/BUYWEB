/**
 * BUYWEB — Authentication & Customer Account Portal UI
 * ====================================================
 * Connects Supabase Auth to BUYWEB navbar, auth modal, and customer account portal.
 */

(function () {
  'use strict';

  const sb = window.BUYWEB_SUPABASE;
  let currentUser = null;
  let userProfile = null;

  // 1. Build and Inject Auth and Account Modal HTML
  function initModals() {
    const markup = `
      <!-- AUTH MODAL -->
      <div class="bw-modal-backdrop" id="bw-auth-modal" hidden>
        <div class="bw-modal-card" role="dialog" aria-modal="true" aria-labelledby="auth-modal-title">
          <button class="bw-modal-close" id="bw-auth-close" aria-label="Close modal">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>

          <div class="bw-auth-header">
            <div class="bw-auth-logo">
              <span class="brand-wordmark" style="font-size: 24px;">BUY<span class="accent-text">WEB</span></span>
            </div>
            <h2 class="bw-auth-title" id="auth-modal-title">Customer Account</h2>
            <p class="bw-auth-sub">Access your purchased templates, licences, and downloads.</p>
          </div>

          <!-- Auth Mode Tabs -->
          <div class="bw-auth-tabs" id="bw-auth-tabs">
            <button class="bw-auth-tab active" data-tab="signin">Sign In</button>
            <button class="bw-auth-tab" data-tab="signup">Create Account</button>
          </div>

          <!-- Sign In Form -->
          <form class="bw-auth-form" id="bw-signin-form">
            <div class="form-group">
              <label for="signin-email">Email Address</label>
              <input type="email" id="signin-email" required placeholder="you@email.com" autocomplete="email" />
            </div>
            <div class="form-group">
              <label for="signin-password">Password</label>
              <input type="password" id="signin-password" required placeholder="••••••••" autocomplete="current-password" />
            </div>
            <div id="signin-error" class="field-error" style="display:block; min-height: 18px;"></div>
            <button type="submit" class="btn btn-primary btn-full">
              Sign In to Account
            </button>
            <div class="bw-auth-footer-links">
              <a id="bw-forgot-pass-btn">Forgot your password?</a>
            </div>
          </form>

          <!-- Sign Up Form -->
          <form class="bw-auth-form" id="bw-signup-form" style="display: none;">
            <div class="form-group">
              <label for="signup-name">Full Name</label>
              <input type="text" id="signup-name" required placeholder="Your name" autocomplete="name" />
            </div>
            <div class="form-group">
              <label for="signup-email">Email Address</label>
              <input type="email" id="signup-email" required placeholder="you@email.com" autocomplete="email" />
            </div>
            <div class="form-group">
              <label for="signup-password">Password (min 6 characters)</label>
              <input type="password" id="signup-password" required minlength="6" placeholder="••••••••" autocomplete="new-password" />
            </div>
            <div id="signup-error" class="field-error" style="display:block; min-height: 18px;"></div>
            <button type="submit" class="btn btn-primary btn-full">
              Create Customer Account
            </button>
          </form>

          <!-- Password Reset Form -->
          <form class="bw-auth-form" id="bw-reset-form" style="display: none;">
            <p style="font-size: var(--text-sm); color: var(--fg-muted);">Enter your account email to receive a password recovery link.</p>
            <div class="form-group">
              <label for="reset-email">Email Address</label>
              <input type="email" id="reset-email" required placeholder="you@email.com" />
            </div>
            <div id="reset-msg" class="field-error" style="display:block; min-height: 18px;"></div>
            <button type="submit" class="btn btn-primary btn-full">Send Recovery Email</button>
            <div class="bw-auth-footer-links">
              <a id="bw-back-to-signin-btn">← Back to Sign In</a>
            </div>
          </form>
        </div>
      </div>

      <!-- CUSTOMER ACCOUNT PORTAL MODAL -->
      <div class="bw-modal-backdrop" id="bw-account-modal" hidden>
        <div class="bw-modal-card bw-modal-wide" role="dialog" aria-modal="true" aria-labelledby="account-modal-title">
          <button class="bw-modal-close" id="bw-account-close" aria-label="Close account modal">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>

          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: var(--space-6);">
            <div>
              <h2 class="bw-auth-title" id="account-modal-title">Customer Portal</h2>
              <p class="bw-auth-sub" id="account-user-meta">Signed in</p>
            </div>
            <button class="btn btn-ghost btn-sm" id="btn-portal-logout" style="color: var(--fg-muted);">
              Sign Out
            </button>
          </div>

          <!-- Portal Nav Tabs -->
          <div class="bw-portal-tabs" id="account-portal-tabs">
            <button class="bw-portal-tab active" data-portal-tab="purchases">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              My Purchases
            </button>
            <button class="bw-portal-tab" data-portal-tab="licences">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              Licences
            </button>
            <button class="bw-portal-tab" data-portal-tab="downloads">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Downloads
            </button>
            <button class="bw-portal-tab" data-portal-tab="enquiries">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
              Customizations
            </button>
          </div>

          <!-- Tab Content Views -->
          <div id="portal-tab-content">
            <div id="portal-loading" style="text-align: center; padding: 40px; color: var(--fg-muted);">Loading your purchases...</div>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', markup);
    attachEventListeners();
  }

  // 2. Attach Event Handlers for Auth and Account
  function attachEventListeners() {
    const authModal = document.getElementById('bw-auth-modal');
    const authClose = document.getElementById('bw-auth-close');
    const accountModal = document.getElementById('bw-account-modal');
    const accountClose = document.getElementById('bw-account-close');
    const tabs = document.querySelectorAll('.bw-auth-tab');
    const signinForm = document.getElementById('bw-signin-form');
    const signupForm = document.getElementById('bw-signup-form');
    const resetForm = document.getElementById('bw-reset-form');
    const forgotBtn = document.getElementById('bw-forgot-pass-btn');
    const backBtn = document.getElementById('bw-back-to-signin-btn');
    const logoutBtn = document.getElementById('btn-portal-logout');

    authClose.addEventListener('click', () => { authModal.hidden = true; });
    accountClose.addEventListener('click', () => { accountModal.hidden = true; });

    // Switch between Sign In / Sign Up tabs
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const mode = tab.dataset.tab;
        if (mode === 'signin') {
          signinForm.style.display = 'flex';
          signupForm.style.display = 'none';
          resetForm.style.display = 'none';
        } else {
          signinForm.style.display = 'none';
          signupForm.style.display = 'flex';
          resetForm.style.display = 'none';
        }
      });
    });

    forgotBtn.addEventListener('click', () => {
      signinForm.style.display = 'none';
      signupForm.style.display = 'none';
      resetForm.style.display = 'flex';
    });

    backBtn.addEventListener('click', () => {
      resetForm.style.display = 'none';
      signinForm.style.display = 'flex';
    });

    // Sign In handler
    signinForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('signin-email').value.trim();
      const password = document.getElementById('signin-password').value;
      const errEl = document.getElementById('signin-error');
      errEl.textContent = '';

      try {
        if (!sb.isConfigured()) {
          throw new Error('Supabase project credentials not yet configured in js/supabase-config.js.');
        }
        await sb.auth.signIn(email, password);
        authModal.hidden = true;
        showToast('Signed in successfully.');
        openAccountModal();
      } catch (err) {
        errEl.textContent = err.message || 'Failed to sign in.';
      }
    });

    // Sign Up handler
    signupForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('signup-name').value.trim();
      const email = document.getElementById('signup-email').value.trim();
      const password = document.getElementById('signup-password').value;
      const errEl = document.getElementById('signup-error');
      errEl.textContent = '';

      try {
        if (!sb.isConfigured()) {
          throw new Error('Supabase project credentials not yet configured in js/supabase-config.js.');
        }
        const data = await sb.auth.signUp(email, password, name);

        // If email confirmation is disabled in Supabase, session is active immediately
        if (data?.session) {
          authModal.hidden = true;
          showToast('Account created and signed in successfully!');
          await syncAuthState();
          openAccountModal();
          return;
        }

        // If user already exists (Supabase returns empty identities array when email confirmation is enabled)
        if (data?.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
          errEl.textContent = 'An account with this email already exists. Please switch to Sign In.';
          return;
        }

        authModal.hidden = true;
        showToast('Account created! Please check your email to confirm registration.');
      } catch (err) {
        const msg = err.message || '';
        if (msg.toLowerCase().includes('rate limit')) {
          errEl.innerHTML = `Supabase email limit exceeded.<br><span style="font-size: 11px; color: var(--fg-muted); line-height: 1.4; display: block; margin-top: 4px;">In your open Supabase tab: go to <strong>Authentication &rarr; Providers &rarr; Email</strong> and turn off <strong>Confirm email</strong>.</span>`;
        } else {
          errEl.textContent = msg || 'Failed to create account.';
        }
      }
    });

    // Reset password handler
    resetForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('reset-email').value.trim();
      const msgEl = document.getElementById('reset-msg');
      msgEl.textContent = '';

      try {
        if (!sb.isConfigured()) {
          throw new Error('Supabase project credentials not yet configured.');
        }
        await sb.auth.resetPassword(email);
        msgEl.style.color = '#22c55e';
        msgEl.textContent = 'Password reset link sent to your email.';
      } catch (err) {
        msgEl.style.color = 'var(--accent)';
        msgEl.textContent = err.message || 'Failed to send recovery email.';
      }
    });

    // Portal Logout
    logoutBtn.addEventListener('click', async () => {
      await sb.auth.signOut();
      accountModal.hidden = true;
      showToast('Signed out of BUYWEB.');
    });

    // Portal Tab switching
    const portalTabs = document.querySelectorAll('.bw-portal-tab');
    portalTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        portalTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderPortalTab(tab.dataset.portalTab);
      });
    });
  }

  // 3. Render Header Navigation Auth Buttons
  function updateNav() {
    const navInner = document.querySelector('.nav-actions');
    if (!navInner) return;

    let authGroup = document.getElementById('nav-auth-group');
    if (!authGroup) {
      authGroup = document.createElement('div');
      authGroup.id = 'nav-auth-group';
      authGroup.className = 'nav-auth-group';
      navInner.prepend(authGroup);
    }

    if (currentUser) {
      const isAdmin = userProfile?.role === 'admin';
      authGroup.innerHTML = `
        ${isAdmin ? `<button class="btn-nav-auth btn-nav-admin" id="btn-nav-admin">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2l7 4v6c0 5-3.5 9-7 10-3.5-1-7-5-7-10V6l7-4z"/></svg>
          Admin Portal
        </button>` : ''}
        <button class="btn-nav-auth" id="btn-nav-account">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          My Account
        </button>
      `;

      document.getElementById('btn-nav-account')?.addEventListener('click', openAccountModal);
      if (isAdmin) {
        document.getElementById('btn-nav-admin')?.addEventListener('click', () => {
          if (window.BUYWEB_ADMIN && typeof window.BUYWEB_ADMIN.open === 'function') {
            window.BUYWEB_ADMIN.open();
          }
        });
      }
    } else {
      authGroup.innerHTML = `
        <button class="btn-nav-auth" id="btn-nav-signin">
          Sign In
        </button>
      `;
      document.getElementById('btn-nav-signin')?.addEventListener('click', openAuthModal);
    }
  }

  // 4. Modal Openers
  function openAuthModal() {
    const modal = document.getElementById('bw-auth-modal');
    if (modal) modal.hidden = false;
  }

  async function openAccountModal() {
    const modal = document.getElementById('bw-account-modal');
    if (!modal) return;
    modal.hidden = false;

    const meta = document.getElementById('account-user-meta');
    if (meta && currentUser) {
      meta.textContent = `${userProfile?.full_name || currentUser.email} (${currentUser.email})`;
    }

    // Default to Purchases tab
    renderPortalTab('purchases');
  }

  // 5. Render Account Portal Tabs (Orders, Licences, Downloads, Customizations)
  async function renderPortalTab(tabKey) {
    const container = document.getElementById('portal-tab-content');
    if (!container) return;
    container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--fg-muted);">Loading data...</div>`;

    try {
      if (tabKey === 'purchases') {
        const orders = await sb.orders.getMyOrders();
        if (orders.length === 0) {
          container.innerHTML = `
            <div style="text-align: center; padding: 40px;">
              <p style="color: var(--fg-muted); margin-bottom: var(--space-4);">No orders found for this account.</p>
              <a href="#store" onclick="document.getElementById('bw-account-modal').hidden=true" class="btn btn-primary btn-sm">Explore Ready-Made Websites</a>
            </div>`;
          return;
        }

        let rows = orders.map(ord => {
          const items = (ord.order_items || []).map(i => i.product_name_snapshot).join(', ') || 'Website Template';
          const totalFormatted = (ord.total_amount / 100).toLocaleString('en-IN', { style: 'currency', currency: ord.currency });
          const dateStr = new Date(ord.created_at).toLocaleDateString();

          return `
            <tr>
              <td><strong>${ord.order_number}</strong></td>
              <td>${items}</td>
              <td>${totalFormatted}</td>
              <td><span class="bw-badge bw-badge-${ord.payment_status}">${ord.payment_status}</span></td>
              <td>${dateStr}</td>
            </tr>`;
        }).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Products</th>
                  <th>Total</th>
                  <th>Payment</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;
      } else if (tabKey === 'licences') {
        const licences = await sb.licences.getMyLicences();
        if (licences.length === 0) {
          container.innerHTML = `<p style="text-align: center; padding: 40px; color: var(--fg-muted);">No active licences issued yet.</p>`;
          return;
        }

        let rows = licences.map(lic => {
          const prodName = lic.order_items?.product_name_snapshot || 'Website Template';
          const dateStr = new Date(lic.issued_at).toLocaleDateString();
          return `
            <tr>
              <td><strong>${prodName}</strong></td>
              <td><span class="tech-pill">${lic.licence_type.toUpperCase()}</span></td>
              <td style="max-width: 320px; font-size: 12px; color: var(--fg-muted);">${lic.terms_snapshot || 'Single end product permission.'}</td>
              <td><span class="bw-badge bw-badge-${lic.status}">${lic.status}</span></td>
              <td>${dateStr}</td>
            </tr>`;
        }).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Licence</th>
                  <th>Terms Snapshot</th>
                  <th>Status</th>
                  <th>Issued</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;
      } else if (tabKey === 'downloads') {
        const orders = await sb.orders.getMyOrders();
        const paidItems = [];
        orders.forEach(ord => {
          if (ord.payment_status === 'paid' && ord.order_items) {
            ord.order_items.forEach(item => {
              paidItems.push({ ...item, orderNumber: ord.order_number });
            });
          }
        });

        if (paidItems.length === 0) {
          container.innerHTML = `<p style="text-align: center; padding: 40px; color: var(--fg-muted);">No downloadable purchases available yet. Completed paid orders will appear here.</p>`;
          return;
        }

        let rows = paidItems.map(item => `
          <tr>
            <td><strong>${item.product_name_snapshot}</strong></td>
            <td>${item.orderNumber}</td>
            <td>
              <button class="btn btn-primary btn-sm btn-dl-file" data-item-id="${item.id}">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                Download Source ZIP
              </button>
            </td>
          </tr>
        `).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Product Package</th>
                  <th>Order</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;

        container.querySelectorAll('.btn-dl-file').forEach(btn => {
          btn.addEventListener('click', async () => {
            const itemId = btn.dataset.itemId;
            btn.disabled = true;
            btn.textContent = 'Generating Secure Link...';
            try {
              const res = await sb.downloads.requestDownloadLink(itemId);
              showToast('Temporary download link ready. Starting download...');
              window.open(res.downloadUrl, '_blank');
            } catch (dlErr) {
              alert(dlErr.message || 'Failed to download file.');
            } finally {
              btn.disabled = false;
              btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Download Source ZIP`;
            }
          });
        });
      } else if (tabKey === 'enquiries') {
        const reqs = await sb.customization.getMyRequests();
        if (reqs.length === 0) {
          container.innerHTML = `<p style="text-align: center; padding: 40px; color: var(--fg-muted);">No customization enquiries submitted from this account yet.</p>`;
          return;
        }

        let rows = reqs.map(r => {
          const dateStr = new Date(r.created_at).toLocaleDateString();
          const quoteStr = r.quoted_amount ? (r.quoted_amount / 100).toLocaleString('en-IN', { style: 'currency', currency: r.currency || 'INR' }) : 'Pending Review';
          return `
            <tr>
              <td><strong>${r.request_reference}</strong></td>
              <td>${r.requested_features}</td>
              <td>${quoteStr}</td>
              <td><span class="bw-badge bw-badge-${r.status}">${r.status}</span></td>
              <td>${dateStr}</td>
            </tr>`;
        }).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Reference</th>
                  <th>Feature</th>
                  <th>Quotation</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;
      }
    } catch (e) {
      container.innerHTML = `<p style="color: var(--accent); padding: 20px;">${e.message || 'Failed to load data.'}</p>`;
    }
  }

  function showToast(msg) {
    if (window.FORM && typeof window.FORM.showToast === 'function') {
      window.FORM.showToast(msg);
    }
  }

  // 6. Auth State Synchronization
  async function syncAuthState() {
    currentUser = await sb.auth.getUser();
    if (currentUser) {
      userProfile = await sb.auth.getProfile(currentUser.id);
    } else {
      userProfile = null;
    }
    updateNav();
  }

  // Initialize
  document.addEventListener('DOMContentLoaded', () => {
    initModals();
    syncAuthState();

    sb.auth.onAuthStateChange(async (_event, session) => {
      currentUser = session?.user || null;
      if (currentUser) {
        userProfile = await sb.auth.getProfile(currentUser.id);
      } else {
        userProfile = null;
      }
      updateNav();
    });
  });

  window.BUYWEB_AUTH_UI = {
    openAuthModal,
    openAccountModal,
  };
})();
