/**
 * BUYWEB - Supabase & Gateway Client Configuration
 * ================================================
 * Configured with your Supabase Project: emnrouupsgrcprcvmups
 */

window.BUYWEB_CONFIG = {
  // Supabase Project Settings
  SUPABASE_URL: window.__ENV_SUPABASE_URL || 'https://emnrouupsgrcprcvmups.supabase.co',
  SUPABASE_ANON_KEY: window.__ENV_SUPABASE_ANON_KEY || 'sb_publishable_V5LFhTlAsDzhOQkvAixHkQ_rpNJeo54',
  SUPABASE_JWKS_URL: window.__ENV_SUPABASE_JWKS_URL || 'https://emnrouupsgrcprcvmups.supabase.co/auth/v1/.well-known/jwks.json',

  // Payment Gateway Settings (Razorpay)
  // Set your Key ID: 'rzp_test_...' for testing, or 'rzp_live_...' for production
  RAZORPAY_KEY_ID: window.__ENV_RAZORPAY_KEY_ID || '',

  // Default Store Currency
  CURRENCY: 'INR',

  // Supabase Edge Functions Base URL
  get FUNCTIONS_URL() {
    return `${this.SUPABASE_URL.replace(/\/+$/, '')}/functions/v1`;
  },

  // Helper to verify connection credentials
  isConfigured() {
    return Boolean(
      this.SUPABASE_URL &&
      !this.SUPABASE_URL.includes('YOUR_PROJECT_ID') &&
      this.SUPABASE_ANON_KEY &&
      !this.SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY')
    );
  },
};
