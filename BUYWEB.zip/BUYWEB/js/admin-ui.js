/**
 * BUYWEB — Administrator Dashboard Portal UI
 * ==========================================
 * Real database-driven analytics, order management, refunds, and customization quotes.
 */

(function () {
  'use strict';

  const sb = window.BUYWEB_SUPABASE;

  function initAdminModal() {
    const markup = `
      <div class="bw-modal-backdrop" id="bw-admin-modal" hidden>
        <div class="bw-modal-card bw-modal-full" role="dialog" aria-modal="true" aria-labelledby="admin-modal-title">
          <button class="bw-modal-close" id="bw-admin-close" aria-label="Close admin dashboard">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-6);">
            <div>
              <span class="badge badge-featured" style="margin-bottom: 6px; display: inline-block;">Admin Authorization Active</span>
              <h2 class="bw-auth-title" id="admin-modal-title">BUYWEB Admin Portal</h2>
              <p class="bw-auth-sub">Live database records &amp; operations</p>
            </div>
            <button class="btn btn-ghost btn-sm" id="btn-admin-refresh">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
              Refresh Data
            </button>
          </div>

          <!-- Admin Portal Tabs -->
          <div class="bw-portal-tabs" id="admin-portal-tabs">
            <button class="bw-portal-tab active" data-admin-tab="analytics">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
              Live Analytics
            </button>
            <button class="bw-portal-tab" data-admin-tab="orders">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/></svg>
              Order Management &amp; Refunds
            </button>
            <button class="bw-portal-tab" data-admin-tab="enquiries">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              Customization Quotations
            </button>
            <button class="bw-portal-tab" data-admin-tab="products">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/></svg>
              Catalogue Management
            </button>
          </div>

          <!-- Admin Tab Views -->
          <div id="admin-tab-content">
            <div style="text-align: center; padding: 40px; color: var(--fg-muted);">Loading admin metrics...</div>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', markup);

    const adminClose = document.getElementById('bw-admin-close');
    const adminModal = document.getElementById('bw-admin-modal');
    const refreshBtn = document.getElementById('btn-admin-refresh');
    const adminTabs = document.querySelectorAll('.bw-portal-tab[data-admin-tab]');

    adminClose.addEventListener('click', () => { adminModal.hidden = true; });

    adminTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        adminTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        renderAdminTab(tab.dataset.adminTab);
      });
    });

    refreshBtn.addEventListener('click', () => {
      const activeTab = document.querySelector('.bw-portal-tab[data-admin-tab].active');
      if (activeTab) renderAdminTab(activeTab.dataset.adminTab);
    });
  }

  async function open() {
    const modal = document.getElementById('bw-admin-modal');
    if (modal) modal.hidden = false;
    renderAdminTab('analytics');
  }

  async function renderAdminTab(tabKey) {
    const container = document.getElementById('admin-tab-content');
    if (!container) return;
    container.innerHTML = `<div style="text-align: center; padding: 40px; color: var(--fg-muted);">Loading database data...</div>`;

    try {
      if (tabKey === 'analytics') {
        const stats = await sb.admin.getAnalytics();
        const grossFormatted = (stats.grossSales / 100).toLocaleString('en-IN', { style: 'currency', currency: stats.currency });
        const refundedFormatted = (stats.refundedAmount / 100).toLocaleString('en-IN', { style: 'currency', currency: stats.currency });
        const netFormatted = (stats.netSales / 100).toLocaleString('en-IN', { style: 'currency', currency: stats.currency });

        container.innerHTML = `
          <div class="bw-kpi-grid">
            <div class="bw-kpi-card">
              <span class="bw-kpi-label">Gross Sales</span>
              <span class="bw-kpi-value accent">${grossFormatted}</span>
            </div>
            <div class="bw-kpi-card">
              <span class="bw-kpi-label">Refunded</span>
              <span class="bw-kpi-value" style="color: #ef4444;">${refundedFormatted}</span>
            </div>
            <div class="bw-kpi-card">
              <span class="bw-kpi-label">Net Sales</span>
              <span class="bw-kpi-value accent">${netFormatted}</span>
            </div>
            <div class="bw-kpi-card">
              <span class="bw-kpi-label">Paid Orders</span>
              <span class="bw-kpi-value">${stats.paidOrders} / ${stats.totalOrders}</span>
            </div>
            <div class="bw-kpi-card">
              <span class="bw-kpi-label">Published Templates</span>
              <span class="bw-kpi-value">${stats.publishedProducts}</span>
            </div>
            <div class="bw-kpi-card">
              <span class="bw-kpi-label">Customization Enquiries</span>
              <span class="bw-kpi-value">${stats.totalEnquiries} (${stats.newEnquiries} New)</span>
            </div>
          </div>
          <div style="background: var(--surface-raised); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: var(--space-5);">
            <h3 style="font-size: var(--text-base); font-weight: 700; margin-bottom: var(--space-2);">Database &amp; Security Status</h3>
            <p style="font-size: var(--text-sm); color: var(--fg-muted); line-height: var(--leading-base);">
              All statistics are calculated strictly from PostgreSQL tables: <code>orders</code>, <code>products</code>, and <code>customization_requests</code>.
              Row Level Security is active and enforcing zero-trust permissions.
            </p>
          </div>
        `;
      } else if (tabKey === 'orders') {
        const orders = await sb.admin.getAllOrders();
        if (orders.length === 0) {
          container.innerHTML = `<p style="text-align: center; padding: 40px; color: var(--fg-muted);">No orders recorded in database yet.</p>`;
          return;
        }

        let rows = orders.map(ord => {
          const totalFormatted = (ord.total_amount / 100).toLocaleString('en-IN', { style: 'currency', currency: ord.currency });
          const dateStr = new Date(ord.created_at).toLocaleDateString();
          const isPaid = ord.payment_status === 'paid';

          return `
            <tr>
              <td><strong>${ord.order_number}</strong></td>
              <td>${ord.customer_email}</td>
              <td>${totalFormatted}</td>
              <td><span class="bw-badge bw-badge-${ord.payment_status}">${ord.payment_status}</span></td>
              <td><span style="font-family: monospace; font-size: 11px; color: var(--fg-muted);">${ord.provider_payment_reference || '—'}</span></td>
              <td>${dateStr}</td>
              <td>
                ${isPaid ? `
                  <button class="btn btn-ghost btn-sm btn-process-refund" data-order-id="${ord.id}" data-num="${ord.order_number}" style="color: #ef4444; border-color: rgba(239,68,68,0.3);">
                    Process Refund
                  </button>
                ` : `<span style="color: var(--fg-muted); font-size: 12px;">No actions</span>`}
              </td>
            </tr>`;
        }).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Customer Email</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Payment Ref</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;

        container.querySelectorAll('.btn-process-refund').forEach(btn => {
          btn.addEventListener('click', async () => {
            const ordId = btn.dataset.orderId;
            const ordNum = btn.dataset.num;
            const confirmMsg = confirm(`Are you sure you want to refund Order #${ordNum}?\nThis will update payment status to 'refunded' and revoke customer licences.`);
            if (!confirmMsg) return;

            btn.disabled = true;
            btn.textContent = 'Refunding...';
            try {
              await sb.admin.processRefund(ordId, 'Admin initiated refund');
              alert(`Order #${ordNum} refunded successfully.`);
              renderAdminTab('orders');
            } catch (err) {
              alert(err.message || 'Refund failed.');
              btn.disabled = false;
              btn.textContent = 'Process Refund';
            }
          });
        });
      } else if (tabKey === 'enquiries') {
        const reqs = await sb.admin.getAllEnquiries();
        if (reqs.length === 0) {
          container.innerHTML = `<p style="text-align: center; padding: 40px; color: var(--fg-muted);">No customization enquiries received yet.</p>`;
          return;
        }

        let rows = reqs.map(r => {
          const quoteFormatted = r.quoted_amount ? (r.quoted_amount / 100).toLocaleString('en-IN', { style: 'currency', currency: r.currency || 'INR' }) : '—';
          return `
            <tr>
              <td><strong>${r.request_reference}</strong></td>
              <td>
                <strong>${r.customer_name}</strong><br/>
                <span style="font-size: 11px; color: var(--fg-muted);">${r.customer_email}</span>
              </td>
              <td style="max-width: 250px;">
                <strong>${r.requested_features}</strong><br/>
                <span style="font-size: 12px; color: var(--fg-muted);">${r.detailed_requirements}</span>
              </td>
              <td>${quoteFormatted}</td>
              <td><span class="bw-badge bw-badge-${r.status}">${r.status}</span></td>
              <td>
                <button class="btn btn-primary btn-sm btn-edit-quote" data-req-id="${r.id}" data-ref="${r.request_reference}">
                  Quote
                </button>
              </td>
            </tr>`;
        }).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Reference</th>
                  <th>Client</th>
                  <th>Requirements</th>
                  <th>Current Quote</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;

        container.querySelectorAll('.btn-edit-quote').forEach(btn => {
          btn.addEventListener('click', async () => {
            const reqId = btn.dataset.reqId;
            const ref = btn.dataset.ref;
            const amountInput = prompt(`Enter quotation amount in INR for Enquiry ${ref} (e.g. 5000):`);
            if (!amountInput) return;

            const paise = Math.round(parseFloat(amountInput) * 100);
            const notes = prompt('Internal Admin Notes / Scope Summary:');

            try {
              await sb.admin.quoteEnquiry(reqId, paise, notes || '', 'quoted');
              alert(`Quote of ₹${amountInput} saved for ${ref}.`);
              renderAdminTab('enquiries');
            } catch (err) {
              alert(err.message || 'Failed to update quote.');
            }
          });
        });
      } else if (tabKey === 'products') {
        const products = await sb.products.getPublishedProducts();
        if (!products || products.length === 0) {
          container.innerHTML = `<p style="text-align: center; padding: 40px; color: var(--fg-muted);">No products found in database.</p>`;
          return;
        }

        let rows = products.map(p => {
          const priceFormatted = (p.price / 100).toLocaleString('en-IN', { style: 'currency', currency: p.currency });
          return `
            <tr>
              <td><strong>${p.name}</strong></td>
              <td><code>${p.slug}</code></td>
              <td><span class="tech-pill">${p.category}</span></td>
              <td>${priceFormatted}</td>
              <td><span class="bw-badge bw-badge-active">${p.publication_status}</span></td>
              <td>${p.featured ? '★ Yes' : 'No'}</td>
            </tr>`;
        }).join('');

        container.innerHTML = `
          <div class="bw-table-container">
            <table class="bw-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Slug</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Status</th>
                  <th>Featured</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>`;
      }
    } catch (e) {
      container.innerHTML = `<p style="color: var(--accent); padding: 20px;">${e.message || 'Failed to load admin data.'}</p>`;
    }
  }

  document.addEventListener('DOMContentLoaded', initAdminModal);

  window.BUYWEB_ADMIN = { open };
})();
