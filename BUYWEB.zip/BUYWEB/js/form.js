/**
 * BUYWEB — Contact / Customization Form
 * Client-side validation and simulated submission notice.
 */

(function () {
  'use strict';

  const form    = document.getElementById('contact-form');
  const toast   = document.getElementById('form-toast');
  const toastMsg = document.getElementById('toast-msg');

  if (!form) return;

  /* ── Set min date on date picker ────────────────── */
  const dateInput = document.getElementById('cf-date');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
  }

  /* ── Validation rules ───────────────────────────── */
  const rules = {
    'cf-name': {
      required: true,
      minLength: 2,
      errorId: 'err-name',
      messages: {
        required: 'Please enter your name.',
        minLength: 'Name must be at least 2 characters.',
      },
    },
    'cf-email': {
      required: true,
      pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      errorId: 'err-email',
      messages: {
        required: 'Please enter your email address.',
        pattern: 'Please enter a valid email address.',
      },
    },
    'cf-feature': {
      required: true,
      minLength: 3,
      errorId: 'err-feature',
      messages: {
        required: 'Please describe the feature or change you need.',
        minLength: 'Please provide more detail.',
      },
    },
    'cf-requirements': {
      required: true,
      minLength: 10,
      errorId: 'err-requirements',
      messages: {
        required: 'Please describe your requirements.',
        minLength: 'Please provide more detail (at least 10 characters).',
      },
    },
  };

  /* ── Validate field ─────────────────────────────── */
  function validateField(fieldId) {
    const rule  = rules[fieldId];
    if (!rule) return true;

    const field = document.getElementById(fieldId);
    const errEl = document.getElementById(rule.errorId);
    const group = field.closest('.form-group');
    const val   = field.value.trim();

    let errorMsg = '';

    if (rule.required && !val) {
      errorMsg = rule.messages.required;
    } else if (rule.minLength && val.length < rule.minLength) {
      errorMsg = rule.messages.minLength;
    } else if (rule.pattern && !rule.pattern.test(val)) {
      errorMsg = rule.messages.pattern;
    }

    if (errorMsg) {
      errEl.textContent = errorMsg;
      group.classList.add('has-error');
      field.setAttribute('aria-invalid', 'true');
      return false;
    } else {
      errEl.textContent = '';
      group.classList.remove('has-error');
      field.removeAttribute('aria-invalid');
      return true;
    }
  }

  /* ── Blur validation ────────────────────────────── */
  Object.keys(rules).forEach(fieldId => {
    const field = document.getElementById(fieldId);
    if (field) {
      field.addEventListener('blur', () => validateField(fieldId));
      field.addEventListener('input', () => {
        if (field.closest('.form-group').classList.contains('has-error')) {
          validateField(fieldId);
        }
      });
    }
  });

  /* ── Form submit ────────────────────────────────── */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Validate all fields
    let isValid = true;
    Object.keys(rules).forEach(fieldId => {
      if (!validateField(fieldId)) isValid = false;
    });

    if (!isValid) {
      // Focus first error field
      const firstError = form.querySelector('.has-error input, .has-error textarea');
      if (firstError) firstError.focus();
      return;
    }

    const sb = window.BUYWEB_SUPABASE;
    if (sb && sb.isConfigured()) {
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending Enquiry...';

      try {
        const formData = {
          name: document.getElementById('cf-name').value.trim(),
          email: document.getElementById('cf-email').value.trim(),
          website: document.getElementById('cf-website')?.value || '',
          feature: document.getElementById('cf-feature').value.trim(),
          requirements: document.getElementById('cf-requirements').value.trim(),
          budget: document.getElementById('cf-budget')?.value || '',
          preferredDate: document.getElementById('cf-date')?.value || '',
        };

        const res = await sb.customization.submitRequest(formData);
        showToast(`✓ Enquiry received! Tracking Reference: #${res.reference}`, 7000);
        form.reset();
      } catch (err) {
        showToast(err.message || 'Failed to submit enquiry. Please try again.', 6000);
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
      return;
    }

    // Fallback notice if Supabase is not yet configured
    showConfigNotice();
  });

  /* ── Config notice ──────────────────────────────── */
  function showConfigNotice() {
    showToast('⚙ Form is not yet connected. Configure a backend or email service before use.', 6000);
  }

  /* ── Show toast ─────────────────────────────────── */
  function showToast(message, duration = 4000) {
    toastMsg.textContent = message;
    toast.hidden = false;

    // Clear existing timer
    if (toast._hideTimer) clearTimeout(toast._hideTimer);

    toast._hideTimer = setTimeout(() => {
      toast.hidden = true;
    }, duration);
  }

  /* ── Export for potential use ───────────────────── */
  window.FORM = { showToast };

})();
