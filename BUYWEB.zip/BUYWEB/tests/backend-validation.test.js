/**
 * BUYWEB — Supabase Backend & Security Test Suite
 * ===============================================
 * Automated verification of PostgreSQL schema constraints, RLS policies,
 * cryptographic payment verification, download access rules, and secret hygiene.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

let totalTests = 0;
let passedTests = 0;
let failedTests = 0;

function assert(condition, message) {
  totalTests++;
  if (condition) {
    passedTests++;
    console.log(`  ✓ PASS: ${message}`);
  } else {
    failedTests++;
    console.error(`  ✗ FAIL: ${message}`);
  }
}

// ────────────────────────────────────────────────────────────────────────────
// 1. DATABASE SCHEMA & CONSTRAINT VALIDATION
// ────────────────────────────────────────────────────────────────────────────
console.log('\n--- 1. DATABASE SCHEMA & CONSTRAINT VALIDATION ---');
const migration01 = fs.readFileSync(path.join(__dirname, '../supabase/migrations/20261026000001_initial_schema.sql'), 'utf8');

// Required Tables
const requiredTables = [
  'profiles',
  'products',
  'orders',
  'order_items',
  'licences',
  'customization_requests',
  'download_records',
  'payment_events',
  'audit_logs',
];
requiredTables.forEach(tbl => {
  assert(migration01.includes(`CREATE TABLE public.${tbl}`), `Table public.${tbl} defined in migrations`);
});

// Primary keys and Foreign Keys
assert(migration01.includes('REFERENCES auth.users(id) ON DELETE CASCADE'), 'Profiles references auth.users(id) with CASCADE');
assert(migration01.includes('order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE'), 'Order items references orders(id) with CASCADE');
assert(migration01.includes('product_id UUID REFERENCES public.products(id) ON DELETE SET NULL'), 'Order items references products(id) with SET NULL');
assert(migration01.includes('order_item_id UUID NOT NULL REFERENCES public.order_items(id) ON DELETE CASCADE'), 'Licences references order_items(id)');

// Financial Constraints & Role Validations
assert(migration01.includes("CHECK (role IN ('customer', 'admin'))"), 'Profile role restricted to customer and admin');
assert(migration01.includes('CHECK (price >= 0)'), 'Products table validates non-negative price (BIGINT)');
assert(migration01.includes('CHECK (subtotal >= 0)'), 'Orders table validates non-negative subtotal');
assert(migration01.includes('CHECK (total_amount >= 0)'), 'Orders table validates non-negative total_amount');
assert(migration01.includes('CHECK (quantity > 0)'), 'Order items validates positive quantity');

// Deduplication on Payment Events
assert(migration01.includes('CONSTRAINT uq_payment_event UNIQUE (provider, provider_event_id)'), 'Payment events table enforces unique constraint on (provider, provider_event_id)');

// ────────────────────────────────────────────────────────────────────────────
// 2. ROW LEVEL SECURITY (RLS) POLICIES VALIDATION
// ────────────────────────────────────────────────────────────────────────────
console.log('\n--- 2. ROW LEVEL SECURITY (RLS) POLICIES VALIDATION ---');
const migration02 = fs.readFileSync(path.join(__dirname, '../supabase/migrations/20261026000002_row_level_security.sql'), 'utf8');

requiredTables.forEach(tbl => {
  assert(migration02.includes(`ALTER TABLE public.${tbl} ENABLE ROW LEVEL SECURITY`), `Row Level Security explicitly enabled on public.${tbl}`);
});

// Role Tampering & Security Definer Guards
assert(migration01.includes('CREATE OR REPLACE FUNCTION public.guard_profile_role_update'), 'Database trigger function guard_profile_role_update defined');
assert(migration01.includes('CREATE OR REPLACE FUNCTION public.guard_order_status_update'), 'Database trigger function guard_order_status_update defined');
assert(migration01.includes('CREATE OR REPLACE FUNCTION public.is_admin'), 'Security Definer helper function is_admin defined');

// Column Level Protection: storage_file_path must NOT be accessible to anon/authenticated
assert(migration02.includes('REVOKE ALL ON public.products FROM anon, authenticated'), 'Public select revoked on entire products table');
assert(!migration02.includes('GRANT SELECT (storage_file_path) ON public.products TO anon'), 'storage_file_path is excluded from anon/authenticated grant list');
assert(migration01.includes('CREATE OR REPLACE VIEW public.public_products'), 'Safe public_products view provided without storage_file_path');

// Orders & Licences Isolation
assert(migration02.includes('customer_id = auth.uid() OR public.is_admin(auth.uid())'), 'Customer records isolated strictly to auth.uid() or admin');

// ────────────────────────────────────────────────────────────────────────────
// 3. STORAGE BUCKET SPECIFICATIONS
// ────────────────────────────────────────────────────────────────────────────
console.log('\n--- 3. STORAGE BUCKET SPECIFICATIONS ---');
const migration03 = fs.readFileSync(path.join(__dirname, '../supabase/migrations/20261026000003_storage_buckets.sql'), 'utf8');

assert(migration03.includes("'buyweb-previews'"), 'Public bucket buyweb-previews defined');
assert(migration03.includes("'buyweb-source-files'"), 'Private bucket buyweb-source-files defined');
assert(migration03.includes("false, -- Strictly PRIVATE bucket"), 'buyweb-source-files is configured as private (public = false)');
assert(migration03.includes('bucket_id = \'buyweb-source-files\' AND public.is_admin(auth.uid())'), 'Direct access to buyweb-source-files restricted strictly to admin');

// ────────────────────────────────────────────────────────────────────────────
// 4. CRYPTOGRAPHIC SIGNATURE & PAYMENT LOGIC VERIFICATION
// ────────────────────────────────────────────────────────────────────────────
console.log('\n--- 4. CRYPTOGRAPHIC SIGNATURE & PAYMENT LOGIC ---');

function verifyRazorpaySignature(orderId, paymentId, signature, secret) {
  const hmac = crypto.createHmac('sha256', secret);
  hmac.update(`${orderId}|${paymentId}`);
  const digest = hmac.digest('hex');
  return digest.toLowerCase() === signature.toLowerCase();
}

const testOrderId = 'order_test_12345';
const testPaymentId = 'pay_test_67890';
const testSecret = 'secret_key_production_sample_987';

// Generate true signature
const trueHmac = crypto.createHmac('sha256', testSecret);
trueHmac.update(`${testOrderId}|${testPaymentId}`);
const validSignature = trueHmac.digest('hex');

// Test with valid signature
assert(verifyRazorpaySignature(testOrderId, testPaymentId, validSignature, testSecret) === true, 'HMAC-SHA256 signature verification succeeds for genuine payment payload');

// Test with forged signature
assert(verifyRazorpaySignature(testOrderId, testPaymentId, 'bad_forged_signature_0000', testSecret) === false, 'HMAC-SHA256 signature verification rejects forged signature');

// Test with altered order ID
assert(verifyRazorpaySignature('order_test_forged', testPaymentId, validSignature, testSecret) === false, 'Signature verification fails when orderId is tampered with');

// Test with wrong secret
assert(verifyRazorpaySignature(testOrderId, testPaymentId, validSignature, 'wrong_secret') === false, 'Signature verification fails when checked against different secret');

// ────────────────────────────────────────────────────────────────────────────
// 5. DOWNLOAD AUTHORIZATION STATE MACHINE
// ────────────────────────────────────────────────────────────────────────────
console.log('\n--- 5. DOWNLOAD AUTHORIZATION STATE MACHINE ---');

function evaluateDownloadEligibility(authUserId, orderCustomerId, paymentStatus, orderStatus, licenceStatus, filePath) {
  if (!authUserId) return { status: 401, error: 'Authentication required' };
  if (authUserId !== orderCustomerId) return { status: 403, error: 'Access denied: not purchase owner' };
  if (paymentStatus !== 'paid') return { status: 403, error: 'Download unavailable: unpaid order' };
  if (orderStatus === 'refunded' || orderStatus === 'cancelled') return { status: 403, error: 'Order cancelled or refunded' };
  if (licenceStatus !== 'active') return { status: 403, error: 'Licence is inactive or revoked' };
  if (!filePath) return { status: 404, error: 'Downloadable archive missing' };
  return { status: 200, success: true };
}

assert(evaluateDownloadEligibility(null, 'user-1', 'paid', 'completed', 'active', 'file.zip').status === 401, 'Unauthenticated user rejected with 401');
assert(evaluateDownloadEligibility('user-2', 'user-1', 'paid', 'completed', 'active', 'file.zip').status === 403, 'Cross-customer access (User B requesting User A purchase) rejected with 403');
assert(evaluateDownloadEligibility('user-1', 'user-1', 'pending', 'pending', 'active', 'file.zip').status === 403, 'Unpaid pending order rejected with 403');
assert(evaluateDownloadEligibility('user-1', 'user-1', 'refunded', 'refunded', 'revoked', 'file.zip').status === 403, 'Refunded order with revoked licence rejected with 403');
assert(evaluateDownloadEligibility('user-1', 'user-1', 'paid', 'completed', 'active', null).status === 404, 'Order with missing file path returns 404');
assert(evaluateDownloadEligibility('user-1', 'user-1', 'paid', 'completed', 'active', 'templates/corp.zip').status === 200, 'Eligible paid purchase by owner returns 200 OK');

// ────────────────────────────────────────────────────────────────────────────
// 6. ZERO SECRET LEAKAGE VERIFICATION
// ────────────────────────────────────────────────────────────────────────────
console.log('\n--- 6. ZERO SECRET LEAKAGE CHECK IN CLIENT ASSETS ---');

const clientFiles = [
  'index.html',
  'js/data.js',
  'js/store.js',
  'js/modal.js',
  'js/form.js',
  'js/nav.js',
  'js/main.js',
  'js/supabase-config.js',
  'js/supabase-client.js',
  'js/auth-ui.js',
  'js/admin-ui.js',
];

clientFiles.forEach(file => {
  const content = fs.readFileSync(path.join(__dirname, '..', file), 'utf8');
  assert(!content.includes('service_role'), `${file} does not contain service_role token`);
  assert(!content.includes('RAZORPAY_KEY_SECRET'), `${file} does not expose RAZORPAY_KEY_SECRET`);
  assert(!content.includes('RAZORPAY_WEBHOOK_SECRET'), `${file} does not expose RAZORPAY_WEBHOOK_SECRET`);
  assert(!content.includes('RESEND_API_KEY'), `${file} does not expose RESEND_API_KEY`);
});

// ────────────────────────────────────────────────────────────────────────────
// SUMMARY
// ────────────────────────────────────────────────────────────────────────────
console.log('\n==================================================');
console.log(`TEST RESULTS: ${passedTests} PASSED, ${failedTests} FAILED (TOTAL: ${totalTests})`);
console.log('==================================================\n');

if (failedTests > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
