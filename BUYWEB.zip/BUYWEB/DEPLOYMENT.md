# BUYWEB — Supabase Backend Deployment & Launch Guide

This guide provides step-by-step instructions to configure, deploy, and verify the Supabase backend for **BUYWEB**.

---

## Architecture Overview

```
                                      ┌────────────────────────────────────────────────────────┐
                                      │                    SUPABASE CLOUD                      │
                                      │                                                        │
┌─────────────────────────┐           │   ┌───────────────────┐        ┌───────────────────┐   │
│     BUYWEB Frontend     │───────────┼──▶│   Supabase Auth   │        │ Supabase Storage  │   │
│  (HTML5 / CSS / Vanilla)│           │   └───────────────────┘        │  buyweb-previews  │   │
└────────────┬────────────┘           │                                │buyweb-source-files│   │
             │                        │                                └───────────────────┘   │
             │ Secure Edge Calls      │                                                        │
             ▼                        │   ┌───────────────────┐        ┌───────────────────┐   │
┌─────────────────────────┐           │   │  PostgreSQL + RLS │◀───────│  Edge Functions   │   │
│  Payment Gateway UI     │◀──────────┼───│  9 Tables/Triggers│        │  create-order     │   │
│  (Razorpay Checkout)    │           │   └───────────────────┘        │  verify-payment   │   │
└─────────────────────────┘           │                                │  payment-webhook  │   │
                                      │                                │create-download-link   │
                                      └────────────────────────────────────────────────────────┘
```

---

## 1. Supabase Project Setup

1. Log in to [Supabase](https://supabase.com) and create a new project named **BUYWEB**.
2. Select your closest database region (e.g. `ap-south-1` Mumbai for India-centric operations).
3. Record your:
   - **Project URL** (`https://[project-ref].supabase.co`)
   - **Anon Key** (Publishable API Key)
   - **Service Role Key** (Keep strictly secret — do not put in frontend code)

---

## 2. Apply Database Migrations

You can apply the SQL migrations using either the Supabase CLI or the Supabase Studio SQL Editor.

### Method A: Via Supabase CLI (Recommended)

```bash
# Log in to Supabase CLI
supabase login

# Link your local repository to your remote Supabase project
supabase link --project-ref [YOUR_PROJECT_REF]

# Push all migrations and seed data
supabase db push
```

### Method B: Via Supabase Studio SQL Editor

Run the migration files in numerical order in the SQL Editor:
1. `supabase/migrations/20261026000001_initial_schema.sql` (Tables, constraints, triggers)
2. `supabase/migrations/20261026000002_row_level_security.sql` (RLS policies)
3. `supabase/migrations/20261026000003_storage_buckets.sql` (Storage buckets & storage RLS)
4. `supabase/migrations/20261026000004_seed_data.sql` (Seeds 11 ready-made website templates)

---

## 3. Configure Supabase Storage

The migration automatically creates two buckets:
1. `buyweb-previews`: **Public bucket** for website thumbnail previews and gallery images.
2. `buyweb-source-files`: **Strictly private bucket** for template ZIP packages and source code.

### Uploading Template Source Archives
In the Supabase Dashboard under **Storage > buyweb-source-files**:
Create a `templates/` folder and upload each template package matching the seed paths:
- `templates/corporate-pro-source-v1.0.zip`
- `templates/nexus-business-source-v1.0.zip`
- `templates/folio-edge-source-v1.0.zip`
- `templates/agency-noir-source-v1.0.zip`
- `templates/bistro-luxe-source-v1.0.zip`
- `templates/shopfront-source-v1.0.zip`
- `templates/launchpad-saas-source-v1.0.zip`
- `templates/persona-source-v1.0.zip`
- `templates/estatepro-source-v1.0.zip`
- `templates/learnhub-source-v1.0.zip`
- `templates/ironfit-source-v1.0.zip`

---

## 4. Deploy Supabase Edge Functions

Deploy each server-side function using the Supabase CLI:

```bash
supabase functions deploy create-order --no-verify-jwt
supabase functions deploy verify-payment --no-verify-jwt
supabase functions deploy payment-webhook --no-verify-jwt
supabase functions deploy create-download-link --no-verify-jwt
supabase functions deploy submit-customization-request --no-verify-jwt
supabase functions deploy process-refund --no-verify-jwt
supabase functions deploy admin-actions --no-verify-jwt
```

---

## 5. Configure Edge Function Secrets

Set the server-side environment secrets for your deployed Edge Functions:

```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY="YOUR_SUPABASE_SERVICE_ROLE_KEY"
supabase secrets set RAZORPAY_KEY_ID="rzp_test_..."
supabase secrets set RAZORPAY_KEY_SECRET="YOUR_RAZORPAY_SECRET"
supabase secrets set RAZORPAY_WEBHOOK_SECRET="YOUR_RAZORPAY_WEBHOOK_SECRET"
supabase secrets set RESEND_API_KEY="re_..."
```

---

## 6. Configure Payment Gateway (Razorpay)

1. Register or log in at [Razorpay Dashboard](https://dashboard.razorpay.com).
2. Go to **Settings > API Keys** and generate test/live keys:
   - Copy **Key Id** (public: set in `js/supabase-config.js` and Edge Function secrets).
   - Copy **Key Secret** (server-only: set in Edge Function secrets).
3. Go to **Settings > Webhooks** and add a new webhook:
   - **Webhook URL**: `https://[YOUR_PROJECT_REF].supabase.co/functions/v1/payment-webhook`
   - **Secret**: Generate a random secure secret and set it as `RAZORPAY_WEBHOOK_SECRET`.
   - **Active Events**:
     - `payment.captured`
     - `payment.failed`
     - `refund.processed`

---

## 7. Connect Frontend to Supabase

Open `js/supabase-config.js` and set your credentials:

```javascript
window.BUYWEB_CONFIG = {
  SUPABASE_URL: 'https://[YOUR_PROJECT_REF].supabase.co',
  SUPABASE_ANON_KEY: '[YOUR_SUPABASE_ANON_KEY]',
  RAZORPAY_KEY_ID: 'rzp_test_[YOUR_KEY_ID]',
  CURRENCY: 'INR',
};
```

---

## 8. Assign Administrator Access

For security, public registration assigns the `'customer'` role by default. To promote your account to administrator:

1. Register an account through the BUYWEB frontend website.
2. Open the Supabase SQL Editor and run:
   ```sql
   UPDATE public.profiles
   SET role = 'admin'
   WHERE email = 'your-admin-email@example.com';
   ```
3. Refresh the website and log in: you will see the **Admin Portal** button appear in the header navigation.

---

## 9. Launch Security Checklist

- [ ] Row Level Security (RLS) is enabled on all 9 tables.
- [ ] Direct select on `storage_file_path` is revoked from public and authenticated roles.
- [ ] `buyweb-source-files` bucket is verified as private (public = false).
- [ ] No `service_role` or secret keys are present in client files (`.env.example` verified).
- [ ] Razorpay webhook HMAC signature verification is active.
- [ ] Database test suite passes: `node tests/backend-validation.test.js` (93/93 passing).
